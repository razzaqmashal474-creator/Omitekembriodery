#!/usr/bin/env python3
"""Generate OMITEK Embroidery app icons (PNG) using PIL."""
from PIL import Image, ImageDraw, ImageFont
import os

OUTPUT_DIR = "/home/z/my-project/public"
os.makedirs(OUTPUT_DIR, exist_ok=True)

EMERALD = (16, 185, 129)
EMERALD_DARK = (4, 120, 87)
WHITE = (255, 255, 255)

def draw_gradient_rounded_square(size, radius, color_top, color_bottom):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    grad = Image.new("RGBA", (size, size))
    for y in range(size):
        t = y / max(size - 1, 1)
        r = int(color_top[0] + (color_bottom[0] - color_top[0]) * t)
        g = int(color_top[1] + (color_bottom[1] - color_top[1]) * t)
        b = int(color_top[2] + (color_bottom[2] - color_top[2]) * t)
        for x in range(size):
            grad.putpixel((x, y), (r, g, b, 255))
    mask = Image.new("L", (size, size), 0)
    mdraw = ImageDraw.Draw(mask)
    mdraw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    img.paste(grad, (0, 0), mask)
    return img

def draw_scissors(draw, cx, cy, scale, color, line_width):
    def tx(x, y):
        return (cx + (x - 12) * scale, cy + (y - 12) * scale)
    c1 = tx(6, 6)
    c2 = tx(6, 18)
    r = 3 * scale
    draw.ellipse([c1[0]-r, c1[1]-r, c1[0]+r, c1[1]+r], outline=color, width=line_width)
    draw.ellipse([c2[0]-r, c2[1]-r, c2[0]+r, c2[1]+r], outline=color, width=line_width)
    p1 = tx(8.12, 8.12)
    p2 = tx(12, 12)
    p3 = tx(20, 4)
    p4 = tx(8.12, 15.88)
    p5 = tx(14.47, 14.48)
    p6 = tx(20, 20)
    draw.line([p1, p2], fill=color, width=line_width)
    draw.line([p3, p4], fill=color, width=line_width)
    draw.line([p5, p6], fill=color, width=line_width)

def find_font(size, bold=True):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]
    for c in candidates:
        if os.path.exists(c):
            return ImageFont.truetype(c, size)
    return ImageFont.load_default()

def make_icon(size, with_text=False, apple=False):
    if apple:
        img = Image.new("RGBA", (size, size), EMERALD + (255,))
        draw = ImageDraw.Draw(img)
        scale = size / 36
        draw_scissors(draw, size // 2, size // 2 - (size // 8 if with_text else 0), scale, WHITE, max(3, int(size // 60)))
        if with_text:
            font = find_font(int(size * 0.18))
            text = "OMITEK"
            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            draw.text(((size - tw) // 2, size - int(size * 0.28)), text, fill=WHITE, font=font)
        return img

    radius = int(size * 0.22)
    img = draw_gradient_rounded_square(size, radius, EMERALD, EMERALD_DARK)
    draw = ImageDraw.Draw(img)
    scale = size / 36
    cy = size // 2 - (size // 8 if with_text else 0)
    draw_scissors(draw, size // 2, cy, scale, WHITE, max(3, int(size // 60)))
    if with_text:
        font = find_font(int(size * 0.18))
        text = "OMITEK"
        bbox = draw.textbbox((0, 0), text, font=font)
        tw = bbox[2] - bbox[0]
        draw.text(((size - tw) // 2, size - int(size * 0.28)), text, fill=WHITE, font=font)
    return img

sizes = {
    "icon-192.png": (192, True),
    "icon-512.png": (512, True),
    "apple-touch-icon.png": (180, True),
    "favicon-32.png": (32, False),
    "favicon-16.png": (16, False),
}

for filename, (size, with_text) in sizes.items():
    is_apple = filename.startswith("apple-touch-icon")
    img = make_icon(size, with_text=with_text, apple=is_apple)
    img.save(os.path.join(OUTPUT_DIR, filename))
    print(f"Generated {filename} ({size}x{size})")

svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#10b981"/>
      <stop offset="1" stop-color="#047857"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="110" fill="url(#bg)"/>
  <g transform="translate(176 96) scale(13)" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="6" cy="6" r="3"/>
    <circle cx="6" cy="18" r="3"/>
    <line x1="8.12" y1="8.12" x2="12" y2="12"/>
    <line x1="20" y1="4" x2="8.12" y2="15.88"/>
    <line x1="14.47" y1="14.48" x2="20" y2="20"/>
  </g>
  <text x="256" y="430" font-family="Arial Black, Arial, sans-serif" font-size="72" font-weight="900" text-anchor="middle" fill="white" letter-spacing="6">OMITEK</text>
</svg>"""
with open(os.path.join(OUTPUT_DIR, "icon.svg"), "w") as f:
    f.write(svg)
print("Generated icon.svg")
print("\nAll icons generated in", OUTPUT_DIR)

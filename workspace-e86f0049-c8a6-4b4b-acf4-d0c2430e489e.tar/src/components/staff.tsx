"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserPlus, Trash2, Users, Shield, KeyRound } from "lucide-react";
import { AppData, StaffUser, StaffRole } from "@/lib/types";
import { formatDate } from "@/lib/format";

interface StaffProps {
  data: AppData;
  currentUser: StaffUser | null | undefined;
  onAdd: (input: Omit<StaffUser, "id" | "createdAt">) => StaffUser;
  onUpdate: (id: string, patch: Partial<StaffUser>) => void;
  onDelete: (id: string) => void;
  onUpdateSettings: (patch: Partial<AppData["settings"]>) => void;
}

export default function Staff({ data, currentUser, onAdd, onUpdate, onDelete, onUpdateSettings }: StaffProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [role, setRole] = useState<StaffRole>("staff");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !username.trim() || !/^\d{4,6}$/.test(pin)) {
      alert("Enter name, username, and a 4-6 digit PIN.");
      return;
    }
    if (data.staff.some((s) => s.username.toLowerCase() === username.trim().toLowerCase())) {
      alert("Username already taken.");
      return;
    }
    onAdd({
      name: name.trim(),
      username: username.trim().toLowerCase(),
      pin,
      role,
      active: true,
    });
    setName(""); setUsername(""); setPin(""); setRole("staff");
    setOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Users className="h-6 w-6 text-emerald-600" /> Staff & Permissions
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Staff log in with username + PIN. Admins can do everything; staff only what you allow.
          </p>
        </div>
        <Button onClick={() => setOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <UserPlus className="mr-2 h-4 w-4" /> Add Staff
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Shield className="h-4 w-4" /> Staff Permissions</CardTitle>
          <CardDescription>What can staff-role users access? (Admins always have full access.)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <PermRow
            label="Manage parties & customers"
            desc="Add parties, record transactions"
            checked={data.settings.staffCanManageParties}
            onChange={(v) => onUpdateSettings({ staffCanManageParties: v })}
          />
          <PermRow
            label="Manage stock"
            desc="Add/edit lace, adjust stock"
            checked={data.settings.staffCanManageStock}
            onChange={(v) => onUpdateSettings({ staffCanManageStock: v })}
          />
          <PermRow
            label="View reports"
            desc="P&L, analytics, sales reports"
            checked={data.settings.staffCanSeeReports}
            onChange={(v) => onUpdateSettings({ staffCanSeeReports: v })}
          />
          <PermRow
            label="Backup & settings"
            desc="Export data, change settings"
            checked={data.settings.staffCanSeeBackup}
            onChange={(v) => onUpdateSettings({ staffCanSeeBackup: v })}
          />
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Username</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.staff.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No staff added yet. Add a staff member to enable login.
                  </TableCell>
                </TableRow>
              ) : (
                data.staff.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="font-medium">
                      {s.name}
                      {currentUser?.id === s.id && <Badge variant="secondary" className="ml-2 text-xs">You</Badge>}
                    </TableCell>
                    <TableCell className="font-mono">{s.username}</TableCell>
                    <TableCell>
                      {s.role === "admin" ? (
                        <Badge className="bg-emerald-600 text-white">Admin</Badge>
                      ) : (
                        <Badge variant="secondary">Staff</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={s.active}
                        onCheckedChange={(v) => onUpdate(s.id, { active: v })}
                      />
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{formatDate(s.createdAt)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        disabled={s.role === "admin" && data.staff.filter((x) => x.role === "admin").length === 1}
                        onClick={() => { if (confirm(`Delete staff user "${s.name}"?`)) onDelete(s.id); }}
                      >
                        <Trash2 className="h-4 text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5" /> Add Staff User</DialogTitle>
            <DialogDescription>They will log in with their username + PIN.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAdd} className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="uname">Full Name *</Label>
              <Input id="uname" required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Bilal Ahmed" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="uuser">Username *</Label>
              <Input id="uuser" required value={username} onChange={(e) => setUsername(e.target.value)} placeholder="e.g. bilal" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="upin">PIN (4-6 digits) *</Label>
              <Input id="upin" required inputMode="numeric" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} placeholder="1234" />
            </div>
            <div className="space-y-1">
              <Label>Role</Label>
              <Select value={role} onValueChange={(v) => setRole(v as StaffRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="staff">Staff (limited)</SelectItem>
                  <SelectItem value="admin">Admin (full access)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">Add</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PermRow({ label, desc, checked, onChange }: { label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between p-3 rounded-md border">
      <div>
        <div className="font-medium text-sm">{label}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

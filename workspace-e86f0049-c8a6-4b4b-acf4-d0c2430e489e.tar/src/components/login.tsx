"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Scissors, LogIn, UserCircle } from "lucide-react";
import { AppData } from "@/lib/types";

interface LoginProps {
  data: AppData;
  onLogin: (userId: string) => void;
}

export default function Login({ data, onLogin }: LoginProps) {
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  // If no staff users exist yet, show a "Create admin" prompt
  const noStaff = data.staff.length === 0;
  const [createName, setCreateName] = useState("");
  const [createUser, setCreateUser] = useState("");
  const [createPin, setCreatePin] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const u = data.staff.find(
      (s) => s.username.toLowerCase() === username.trim().toLowerCase() && s.pin === pin && s.active,
    );
    if (!u) {
      setError("Invalid username or PIN. Please try again.");
      return;
    }
    onLogin(u.id);
  };

  const handleCreateAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createName.trim() || !createUser.trim() || !/^\d{4,6}$/.test(createPin)) {
      setError("Enter your name, a username, and a 4-6 digit PIN.");
      return;
    }
    // Create admin locally and immediately log in.
    // We need to use the store addStaff but we don't have direct access — use a callback.
    // Instead, write directly to localStorage via the store's external API.
    // Simpler: dispatch a one-off creation event handled by parent.
    setError("");
    onCreateAdminLocal(createName, createUser, createPin);
  };

  // Fallback: if no staff exists, allow direct access without login.
  // But to enable login, parent will pass setStaff via window.
  const onCreateAdminLocal = (name: string, uname: string, pinStr: string) => {
    // Call the global function set by page.tsx for first-time admin creation
    const w = window as unknown as { __omitekCreateAdmin?: (name: string, uname: string, pin: string) => void };
    if (w.__omitekCreateAdmin) {
      w.__omitekCreateAdmin(name, uname, pinStr);
    }
  };

  if (noStaff) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-slate-50 to-emerald-100 dark:from-slate-950 dark:via-slate-900 dark:to-emerald-950 p-4">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto h-14 w-14 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-2 shadow">
              <Scissors className="h-7 w-7" />
            </div>
            <CardTitle className="text-xl">OMITEK Embroidery</CardTitle>
            <CardDescription>Create your first admin account to get started.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateAdmin} className="space-y-3">
              <div className="space-y-1">
                <Label htmlFor="cname">Your Name *</Label>
                <Input id="cname" required value={createName} onChange={(e) => setCreateName(e.target.value)} placeholder="e.g. Owner" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="cuser">Username *</Label>
                <Input id="cuser" required value={createUser} onChange={(e) => setCreateUser(e.target.value)} placeholder="e.g. admin" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="cpin">PIN (4-6 digits) *</Label>
                <Input
                  id="cpin"
                  required
                  inputMode="numeric"
                  maxLength={6}
                  value={createPin}
                  onChange={(e) => setCreatePin(e.target.value.replace(/\D/g, ""))}
                  placeholder="1234"
                />
              </div>
              {error && <div className="text-sm text-red-600">{error}</div>}
              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                Create Admin Account
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                You can add more staff (with limited permissions) later from the Staff tab.
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-slate-50 to-emerald-100 dark:from-slate-950 dark:via-slate-900 dark:to-emerald-950 p-4">
      <Card className="w-full max-w-sm shadow-lg">
        <CardHeader className="text-center">
          <div className="mx-auto h-14 w-14 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-2 shadow">
            <Scissors className="h-7 w-7" />
          </div>
          <CardTitle className="text-xl">OMITEK Embroidery</CardTitle>
          <CardDescription>Sign in to continue</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="luser"><UserCircle className="inline h-3 w-3 mr-1" /> Username</Label>
              <Input
                id="luser"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="username"
                autoFocus
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="lpin">PIN</Label>
              <Input
                id="lpin"
                required
                inputMode="numeric"
                maxLength={6}
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                placeholder="••••"
              />
            </div>
            {error && <div className="text-sm text-red-600">{error}</div>}
            <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
              <LogIn className="mr-2 h-4 w-4" /> Sign In
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

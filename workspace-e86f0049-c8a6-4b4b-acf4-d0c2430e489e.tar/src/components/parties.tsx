"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, UserPlus, Phone, MapPin, ChevronRight, Users } from "lucide-react";
import { Party, Transaction } from "@/lib/types";
import { partyBalance, partySalesTotal } from "@/lib/store";
import { formatCurrency } from "@/lib/format";

interface PartiesProps {
  parties: Party[];
  transactions: Transaction[];
  currency: string;
  onAdd: (input: { name: string; phone: string; address?: string; notes?: string; openingBalance?: number }) => Party;
  onOpen: (id: string) => void;
}

export default function Parties({ parties, transactions, currency, onAdd, onOpen }: PartiesProps) {
  const [search, setSearch] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [openingBalance, setOpeningBalance] = useState("");
  const [showForm, setShowForm] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return parties;
    return parties.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.phone.toLowerCase().includes(q),
    );
  }, [parties, search]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAdd({
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim() || undefined,
      notes: notes.trim() || undefined,
      openingBalance: openingBalance ? Number(openingBalance) : undefined,
    });
    setName("");
    setPhone("");
    setAddress("");
    setNotes("");
    setOpeningBalance("");
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Users className="h-6 w-6 text-emerald-600" /> Parties / Customers
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Add new customers or search existing ones. Each party has its own account & history.
          </p>
        </div>
        <Button
          onClick={() => setShowForm((v) => !v)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          <UserPlus className="mr-2 h-4 w-4" />
          {showForm ? "Close Form" : "Add Party"}
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>New Party</CardTitle>
            <CardDescription>Register a new customer. Saved on this computer only.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdd} className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="pname">Party Name *</Label>
                <Input
                  id="pname"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ali Traders"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pphone">Mobile Number</Label>
                <Input
                  id="pphone"
                  inputMode="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="03xx-xxxxxxx"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="popening">Opening Balance (Rs.) — Carry Forward</Label>
                <Input
                  id="popening"
                  inputMode="decimal"
                  value={openingBalance}
                  onChange={(e) => setOpeningBalance(e.target.value)}
                  placeholder="0"
                />
                <p className="text-xs text-muted-foreground">
                  If customer already owes money from before, enter it here. It will be added to their account automatically.
                </p>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="paddr">Address</Label>
                <Input
                  id="paddr"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Shop / market address"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="pnotes">Notes</Label>
                <Textarea
                  id="pnotes"
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Optional notes about this customer"
                />
              </div>
              <div className="md:col-span-2 flex gap-2">
                <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">
                  Save Party
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            {parties.length === 0
              ? "No parties yet. Click \"Add Party\" to create your first customer."
              : "No party matches your search."}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {filtered.map((p) => {
            const bal = partyBalance(p.id, transactions);
            const sales = partySalesTotal(p.id, transactions);
            const owes = bal > 0;
            return (
              <button
                key={p.id}
                onClick={() => onOpen(p.id)}
                className="text-left"
              >
                <Card className="hover:border-emerald-400 hover:shadow-md transition cursor-pointer h-full">
                  <CardContent className="p-4 flex items-center gap-4">
                    <Avatar className="h-12 w-12 bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-200">
                      <AvatarFallback>
                        {p.name.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold truncate">{p.name}</span>
                        {owes ? (
                          <Badge variant="destructive" className="text-xs">
                            Balance {formatCurrency(bal, currency)}
                          </Badge>
                        ) : bal < 0 ? (
                          <Badge className="bg-emerald-600 text-white text-xs">
                            Advance {formatCurrency(Math.abs(bal), currency)}
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">Settled</Badge>
                        )}
                      </div>
                      {p.phone && (
                        <div className="text-sm text-muted-foreground flex items-center gap-1 mt-0.5">
                          <Phone className="h-3 w-3" /> {p.phone}
                        </div>
                      )}
                      {p.address && (
                        <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5 truncate">
                          <MapPin className="h-3 w-3" /> {p.address}
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground mt-1">
                        Total sales: {formatCurrency(sales, currency)}
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </CardContent>
                </Card>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

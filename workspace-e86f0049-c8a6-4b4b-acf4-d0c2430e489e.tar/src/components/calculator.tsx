"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Calculator as CalcIcon, RotateCcw, Sparkles } from "lucide-react";
import { calcOneGazPrice, calcPiecePrice, formatCurrency } from "@/lib/format";

interface CalculatorProps {
  currency: string;
}

export default function Calculator({ currency }: CalculatorProps) {
  const [stitch, setStitch] = useState<string>("");
  const [rate, setRate] = useState<string>("");
  const [gazz, setGazz] = useState<string>("22");

  const sNum = Number(stitch) || 0;
  const rNum = Number(rate) || 0;
  const gNum = Number(gazz) || 0;

  const oneGazPrice = useMemo(
    () => calcOneGazPrice(sNum, rNum),
    [sNum, rNum],
  );
  const piecePrice = useMemo(
    () => calcPiecePrice(sNum, rNum),
    [sNum, rNum],
  );
  const customTotal = useMemo(
    () => oneGazPrice * gNum,
    [oneGazPrice, gNum],
  );

  const reset = () => {
    setStitch("");
    setRate("");
    setGazz("22");
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Lace Price Calculator</h2>
        <p className="text-muted-foreground text-sm mt-1">
          Formula: One Gaz = (Stitch × Rate) ÷ 1000 &nbsp;•&nbsp; One Piece = One Gaz × 22
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalcIcon className="h-5 w-5 text-emerald-600" />
              Enter Details
            </CardTitle>
            <CardDescription>
              Type the stitch count and rate to instantly calculate the lace price.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="stitch">Stitch</Label>
              <Input
                id="stitch"
                inputMode="decimal"
                placeholder="e.g. 1200"
                value={stitch}
                onChange={(e) => setStitch(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rate">Rate</Label>
              <Input
                id="rate"
                inputMode="decimal"
                placeholder="e.g. 5"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gazz">Quantity (in Gaz) — default 22</Label>
              <Input
                id="gazz"
                inputMode="decimal"
                placeholder="22"
                value={gazz}
                onChange={(e) => setGazz(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Leave as 22 to calculate one full piece, or change it for a custom length.
              </p>
            </div>
            <Button variant="outline" onClick={reset} className="w-full">
              <RotateCcw className="mr-2 h-4 w-4" /> Reset
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300">
              <Sparkles className="h-5 w-5" />
              Calculation Result
            </CardTitle>
            <CardDescription>Computed automatically as you type.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg bg-white dark:bg-emerald-950/50 p-4 border border-emerald-100 dark:border-emerald-900">
              <div className="text-sm text-muted-foreground">Step 1 · One Gaz price</div>
              <div className="text-xs text-muted-foreground mb-1 font-mono">
                ({sNum} × {rNum}) ÷ 1000
              </div>
              <div className="text-2xl font-bold text-emerald-700 dark:text-emerald-300">
                {formatCurrency(oneGazPrice, currency)}
              </div>
            </div>

            <div className="rounded-lg bg-white dark:bg-emerald-950/50 p-4 border border-emerald-100 dark:border-emerald-900">
              <div className="text-sm text-muted-foreground">Step 2 · One piece (× 22)</div>
              <div className="text-xs text-muted-foreground mb-1 font-mono">
                {formatCurrency(oneGazPrice, currency)} × 22
              </div>
              <div className="text-2xl font-bold text-emerald-700 dark:text-emerald-300">
                {formatCurrency(piecePrice, currency)}
              </div>
            </div>

            <Separator />

            <div className="rounded-lg bg-emerald-600 text-white p-4">
              <div className="text-sm opacity-90">
                Total for {gNum || 0} Gaz
              </div>
              <div className="text-3xl font-extrabold">
                {formatCurrency(customTotal, currency)}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

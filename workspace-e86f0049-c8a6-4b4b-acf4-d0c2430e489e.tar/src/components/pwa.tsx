"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, X, RefreshCw } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

// Register the service worker on mount (client-only, production-safe).
export function usePWARegister() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;
    // Register on https OR localhost (PWA install works on both)
    const onLoad = () => {
      navigator.serviceWorker.register("/sw.js").catch((err) => {
        console.warn("SW registration failed:", err);
      });
    };
    if (document.readyState === "complete") onLoad();
    else window.addEventListener("load", onLoad, { once: true });
  }, []);
}

// Hook that surfaces the "Install app" prompt when the browser fires beforeinstallprompt.
export function usePWAInstallPrompt() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    return standalone;
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (installed) return;
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, [installed]);

  const prompt = async () => {
    if (!deferred) return;
    await deferred.prompt();
    const choice = await deferred.userChoice;
    if (choice.outcome === "accepted") setInstalled(true);
    setDeferred(null);
  };

  return { canInstall: !!deferred && !installed, prompt, installed };
}

// Detect SW update available
export function useSWUpdateAvailable() {
  const [updateAvailable, setUpdateAvailable] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;
    let reg: ServiceWorkerRegistration | null = null;
    navigator.serviceWorker.getRegistration().then((r) => {
      if (!r) return;
      reg = r;
      if (r.waiting) setUpdateAvailable(true);
      r.addEventListener("updatefound", () => {
        if (r.installing) {
          r.installing.addEventListener("statechange", () => {
            if (reg?.waiting) setUpdateAvailable(true);
          });
        }
      });
    });
  }, []);

  const applyUpdate = () => {
    if (typeof navigator === "undefined" || !navigator.serviceWorker.controller) {
      window.location.reload();
      return;
    }
    navigator.serviceWorker.controller.postMessage("SKIP_WAITING");
    setTimeout(() => window.location.reload(), 500);
  };

  return { updateAvailable, applyUpdate };
}

// Visible install + update banner component
export function PWAInstallBanner() {
  const { canInstall, prompt } = usePWAInstallPrompt();
  const { updateAvailable, applyUpdate } = useSWUpdateAvailable();
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  if (updateAvailable) {
    return (
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 max-w-md w-[calc(100%-2rem)] bg-emerald-600 text-white rounded-lg shadow-lg p-3 flex items-center gap-3">
        <RefreshCw className="h-5 w-5 flex-shrink-0" />
        <div className="flex-1 text-sm">
          <div className="font-semibold">Update available</div>
          <div className="text-xs opacity-90">A new version of OMITEK is ready.</div>
        </div>
        <Button
          size="sm"
          variant="secondary"
          onClick={applyUpdate}
          className="bg-white text-emerald-700 hover:bg-emerald-50"
        >
          Update
        </Button>
        <button onClick={() => setDismissed(true)} className="opacity-80 hover:opacity-100">
          <X className="h-4 w-4" />
        </button>
      </div>
    );
  }

  if (canInstall) {
    return (
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 max-w-md w-[calc(100%-2rem)] bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900 rounded-lg shadow-lg p-3 flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center flex-shrink-0">
          <Download className="h-5 w-5" />
        </div>
        <div className="flex-1 text-sm">
          <div className="font-semibold">Install OMITEK app</div>
          <div className="text-xs text-muted-foreground">Faster access · Works offline · Home-screen icon</div>
        </div>
        <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={prompt}>
          Install
        </Button>
        <button onClick={() => setDismissed(true)} className="text-muted-foreground hover:text-foreground">
          <X className="h-4 w-4" />
        </button>
      </div>
    );
  }

  return null;
}

// Server-side wrapper that mounts SW registration + install banner.
// Rendered once at the layout level so it lives across the whole app.
export function PWARegister() {
  usePWARegister();
  return <PWAInstallBanner />;
}

"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Phone, MapPin, Plus, Trash2, Truck, Wallet, ShoppingCart, Scale } from "lucide-react";
import { AppData, Supplier, Purchase } from "@/lib/types";
import { supplierBalance, supplierPurchaseTotal, supplierPaidTotal } from "@/lib/store";
import { calcOneGazPrice, formatCurrency, formatDateTime } from "@/lib/format";

interface SupplierDetailProps {
  supplier: Supplier;
  data: AppData;
  onBack: () => void;
  onAddPurchase: (input: Omit<Purchase, "id" | "date" | "purchaseNo"> & { date?: string }) => Purchase;
  onDeletePurchase: (id: string) => void;
  onUpdatePurchase: (id: string, patch: Partial<Purchase>) => void;
}

export default function SupplierDetail({
  supplier, data, onBack, onAddPurchase, onDeletePurchase, onUpdatePurchase,
}: SupplierDetailProps) {
  const [show, setShow] = useState(false);
  const [laceName, setLaceName] = useState("");
  const [stitch, setStitch] = useState("");
  const [rate, setRate] = useState("");
  const [gazz, setGazz] = useState("");
  const [amountPaid, setAmountPaid] = useState("");
  const [desc, setDesc] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 16));
  const [stockId, setStockId] = useState("none");
  const [payOpen, setPayOpen] = useState<string | null>(null);
  const [payAmount, setPayAmount] = useState("");

  const supPurchases = useMemo(
    () =>
      data.purchases
        .filter((p) => p.supplierId === supplier.id)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
    [data.purchases, supplier.id],
  );

  const bal = supplierBalance(supplier.id, data.purchases) + (supplier.openingBalance || 0);
  const totalPurchased = supplierPurchaseTotal(supplier.id, data.purchases);
  const totalPaid = supplierPaidTotal(supplier.id, data.purchases);

  const computedTotal = useMemo(() => {
    if (!stitch || !rate || !gazz) return 0;
    return calcOneGazPrice(Number(stitch), Number(rate)) * (Number(gazz) || 0);
  }, [stitch, rate, gazz]);

  const reset = () => {
    setLaceName(""); setStitch(""); setRate(""); setGazz("");
    setAmountPaid(""); setDesc(""); setDate(new Date().toISOString().slice(0, 16));
    setStockId("none");
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!laceName.trim() || !stitch || !rate || !gazz) {
      alert("Fill all lace details.");
      return;
    }
    const total = computedTotal;
    const paid = Number(amountPaid) || 0;
    onAddPurchase({
      supplierId: supplier.id,
      stockId: stockId !== "none" ? stockId : undefined,
      laceName: laceName.trim(),
      stitch: Number(stitch),
      rate: Number(rate),
      gazz: Number(gazz),
      totalAmount: total,
      amountPaid: paid,
      description: desc.trim() || undefined,
      date: new Date(date).toISOString(),
    });
    reset();
    setShow(false);
  };

  const handlePay = (id: string) => {
    const amt = Number(payAmount);
    if (!amt || amt <= 0) {
      alert("Enter a valid amount.");
      return;
    }
    const p = data.purchases.find((x) => x.id === id);
    if (!p) return;
    const newPaid = Math.min(p.totalAmount, p.amountPaid + amt);
    onUpdatePurchase(id, { amountPaid: newPaid });
    setPayOpen(null);
    setPayAmount("");
  };

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" onClick={onBack}>
        <ArrowLeft className="h-4 w-4 mr-1" /> All Suppliers
      </Button>

      <Card>
        <CardContent className="p-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Truck className="h-6 w-6 text-emerald-600" /> {supplier.name}
              </h2>
              <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                {supplier.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {supplier.phone}</span>}
                {supplier.address && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {supplier.address}</span>}
              </div>
            </div>
            <div className="flex flex-col items-end">
              <div className="text-sm text-muted-foreground">You owe</div>
              <div className={`text-3xl font-extrabold ${bal > 0 ? "text-red-600" : "text-emerald-600"}`}>
                {formatCurrency(Math.abs(bal), data.settings.currency)}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-amber-100 dark:bg-amber-900/40 p-2.5"><ShoppingCart className="h-5 w-5 text-amber-600" /></div>
            <div><div className="text-xs text-muted-foreground">Total Purchases</div><div className="font-bold">{formatCurrency(totalPurchased, data.settings.currency)}</div></div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-emerald-100 dark:bg-emerald-900/40 p-2.5"><Wallet className="h-5 w-5 text-emerald-600" /></div>
            <div><div className="text-xs text-muted-foreground">Total Paid</div><div className="font-bold">{formatCurrency(totalPaid, data.settings.currency)}</div></div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-red-100 dark:bg-red-900/40 p-2.5"><Scale className="h-5 w-5 text-red-600" /></div>
            <div><div className="text-xs text-muted-foreground">Balance</div><div className="font-bold">{formatCurrency(bal, data.settings.currency)}</div></div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Purchase History</h3>
        <Button onClick={() => setShow(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <Plus className="mr-1 h-4 w-4" /> New Purchase
        </Button>
      </div>

      {supPurchases.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">No purchases yet.</CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>PO No / Date</TableHead>
                    <TableHead>Lace</TableHead>
                    <TableHead className="text-right">Stitch / Rate</TableHead>
                    <TableHead className="text-right">Gaz</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Paid</TableHead>
                    <TableHead className="text-right">Bal</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {supPurchases.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell>
                        <div className="font-medium">{p.purchaseNo}</div>
                        <div className="text-xs text-muted-foreground">{formatDateTime(p.date)}</div>
                      </TableCell>
                      <TableCell>
                        <div>{p.laceName}</div>
                        {p.description && <div className="text-xs text-muted-foreground">{p.description}</div>}
                      </TableCell>
                      <TableCell className="text-right font-mono text-xs">{p.stitch} / {p.rate}</TableCell>
                      <TableCell className="text-right font-mono">{p.gazz}</TableCell>
                      <TableCell className="text-right font-mono">{formatCurrency(p.totalAmount, data.settings.currency)}</TableCell>
                      <TableCell className="text-right font-mono">{formatCurrency(p.amountPaid, data.settings.currency)}</TableCell>
                      <TableCell className="text-right font-mono font-semibold text-red-600">{formatCurrency(p.totalAmount - p.amountPaid, data.settings.currency)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          {p.amountPaid < p.totalAmount && (
                            <Button variant="outline" size="sm" onClick={() => { setPayOpen(p.id); setPayAmount(String(p.totalAmount - p.amountPaid)); }}>
                              Pay
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" onClick={() => { if (confirm("Delete this purchase? Stock will not auto-reduce.")) onDeletePurchase(p.id); }}>
                            <Trash2 className="h-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* New purchase dialog */}
      <Dialog open={show} onOpenChange={setShow}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New Purchase — {supplier.name}</DialogTitle>
            <DialogDescription>
              Buying lace from this supplier. Auto-adds to stock if linked.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAdd} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Date & Time</Label>
                <Input type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Link to stock</Label>
                <Select value={stockId} onValueChange={(v) => {
                  setStockId(v);
                  if (v !== "none") {
                    const item = data.stock.find((s) => s.id === v);
                    if (item) { setLaceName(item.name); }
                  }
                }}>
                  <SelectTrigger><SelectValue placeholder="Auto-create / pick" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Auto-create new</SelectItem>
                    {data.stock.map((s) => (
                      <SelectItem key={s.id} value={s.id}>{s.name} ({s.quantityGaz} Gaz)</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Lace Name *</Label>
                <Input required value={laceName} onChange={(e) => setLaceName(e.target.value)} placeholder="e.g. Cotton Lace" />
              </div>
              <div className="space-y-1">
                <Label>Description</Label>
                <Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Optional" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label>Stitch *</Label>
                <Input required inputMode="decimal" value={stitch} onChange={(e) => setStitch(e.target.value)} placeholder="1200" />
              </div>
              <div className="space-y-1">
                <Label>Rate *</Label>
                <Input required inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="4" />
              </div>
              <div className="space-y-1">
                <Label>Quantity (Gaz) *</Label>
                <Input required inputMode="decimal" value={gazz} onChange={(e) => setGazz(e.target.value)} placeholder="100" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Amount Paid Now</Label>
                <Input inputMode="decimal" value={amountPaid} onChange={(e) => setAmountPaid(e.target.value)} placeholder="0" />
              </div>
              <div className="space-y-1">
                <Label>Computed Total</Label>
                <div className="h-9 rounded-md border bg-muted/40 flex items-center px-3 font-bold">
                  {formatCurrency(computedTotal, data.settings.currency)}
                </div>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Cost/Gaz is calculated from stitch × rate ÷ 1000 and saved to the linked stock item for profit tracking.
            </p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShow(false)}>Cancel</Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">Save Purchase</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Pay dialog */}
      <Dialog open={!!payOpen} onOpenChange={(o) => !o && setPayOpen(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Pay Supplier</DialogTitle>
            <DialogDescription>Record a payment against this purchase.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Amount</Label>
            <Input inputMode="decimal" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPayOpen(null)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => payOpen && handlePay(payOpen)}>Save Payment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Receipt, TrendingDown } from "lucide-react";
import { Expense } from "@/lib/types";
import { formatCurrency, formatDate, isSameMonth, todayISO } from "@/lib/format";

interface ExpensesProps {
  expenses: Expense[];
  currency: string;
  onAdd: (input: Omit<Expense, "id">) => Expense;
  onDelete: (id: string) => void;
}

const CATEGORIES = ["Rent", "Electricity", "Wages", "Purchase", "Transport", "Food", "Misc"];

export default function Expenses({ expenses, currency, onAdd, onDelete }: ExpensesProps) {
  const [open, setOpen] = useState(false);
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Misc");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const thisMonthTotal = useMemo(
    () => expenses.filter((e) => isSameMonth(e.date, todayISO())).reduce((s, e) => s + e.amount, 0),
    [expenses],
  );
  const allTotal = useMemo(() => expenses.reduce((s, e) => s + e.amount, 0), [expenses]);

  const sorted = useMemo(
    () => [...expenses].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
    [expenses],
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(amount);
    if (!desc.trim() || !amt || amt <= 0) {
      alert("Enter a description and a valid amount.");
      return;
    }
    onAdd({
      description: desc.trim(),
      amount: amt,
      category,
      date: new Date(date).toISOString(),
    });
    setDesc("");
    setAmount("");
    setCategory("Misc");
    setDate(new Date().toISOString().slice(0, 10));
    setOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <TrendingDown className="h-6 w-6 text-red-500" /> Expenses
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Track shop expenses (rent, electricity, wages, purchases, etc.).
          </p>
        </div>
        <Button onClick={() => setOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <Plus className="mr-2 h-4 w-4" /> Add Expense
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">This Month</div>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(thisMonthTotal, currency)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">All-time</div>
            <div className="text-2xl font-bold">{formatCurrency(allTotal, currency)}</div>
          </CardContent>
        </Card>
      </div>

      {sorted.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            No expenses recorded yet. Click “Add Expense” to start tracking.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sorted.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell className="whitespace-nowrap">{formatDate(e.date)}</TableCell>
                      <TableCell>{e.description}</TableCell>
                      <TableCell><span className="text-xs px-2 py-0.5 rounded-full bg-muted">{e.category}</span></TableCell>
                      <TableCell className="text-right font-mono">{formatCurrency(e.amount, currency)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => {
                          if (confirm("Delete this expense?")) onDelete(e.id);
                        }}>
                          <Trash2 className="h-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Expense</DialogTitle>
            <DialogDescription>Record a shop expense.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="edesc">Description *</Label>
              <Input id="edesc" required value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="e.g. Shop rent" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="eamt">Amount *</Label>
                <Input id="eamt" required inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" />
              </div>
              <div className="space-y-1">
                <Label>Date</Label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1">
              <Label>Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

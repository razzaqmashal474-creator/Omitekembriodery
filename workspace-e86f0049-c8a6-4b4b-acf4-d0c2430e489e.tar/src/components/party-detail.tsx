"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  ArrowLeft, Phone, MapPin, Plus, Printer, Trash2, ShoppingCart, Wallet, Scale,
  ArrowDownCircle, ArrowUpCircle, RotateCcw, Bell, FileDown, MessageCircle,
} from "lucide-react";
import { AppData, Party, Transaction, TransactionType, LaceStockItem, PaymentMethod, PAYMENT_METHODS } from "@/lib/types";
import { partyBalance, partyPaidTotal, partySalesTotal, partyReturnsTotal } from "@/lib/store";
import { calcOneGazPrice, formatCurrency, formatDateTime, normalizePhone } from "@/lib/format";
import { exportPartyLedgerPDF } from "@/lib/export";
import ReceiptModal from "./receipt-modal";

interface PartyDetailProps {
  party: Party;
  data: AppData;
  onBack: () => void;
  onAddTransaction: (input: Omit<Transaction, "id" | "date" | "receiptNo"> & { date?: string }) => Transaction;
  onDeleteTransaction: (id: string) => void;
  onUpdateStock: (id: string, patch: Partial<LaceStockItem>) => void;
}

export default function PartyDetail({
  party,
  data,
  onBack,
  onAddTransaction,
  onDeleteTransaction,
  onUpdateStock,
}: PartyDetailProps) {
  const [showTx, setShowTx] = useState(false);
  const [receiptTx, setReceiptTx] = useState<Transaction | null>(null);

  // form state
  const [txType, setTxType] = useState<TransactionType>("sale");
  const [txAmount, setTxAmount] = useState<string>("");
  const [txDesc, setTxDesc] = useState<string>("");
  const [txDate, setTxDate] = useState<string>(new Date().toISOString().slice(0, 16));
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash");
  // sale-only fields
  const [laceName, setLaceName] = useState<string>("");
  const [stitch, setStitch] = useState<string>("");
  const [rate, setRate] = useState<string>("");
  const [gazz, setGazz] = useState<string>("");
  const [stockId, setStockId] = useState<string>("none");

  const partyTx = useMemo(
    () =>
      data.transactions
        .filter((t) => t.partyId === party.id)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
    [data.transactions, party.id],
  );

  const bal = partyBalance(party.id, data.transactions);
  const sales = partySalesTotal(party.id, data.transactions);
  const paid = partyPaidTotal(party.id, data.transactions);
  const returns = partyReturnsTotal(party.id, data.transactions);

  const withRunning = useMemo(() => {
    const sorted = [...partyTx].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
    );
    let running = 0;
    const map = new Map<string, number>();
    sorted.forEach((t) => {
      if (t.type === "sale" || t.type === "opening") running += t.amount;
      else running -= t.amount;
      map.set(t.id, running);
    });
    return map;
  }, [partyTx]);

  const resetForm = () => {
    setTxType("sale");
    setTxAmount("");
    setTxDesc("");
    setTxDate(new Date().toISOString().slice(0, 16));
    setPaymentMethod("cash");
    setLaceName("");
    setStitch("");
    setRate("");
    setGazz("");
    setStockId("none");
  };

  const computedAmount = useMemo(() => {
    if (txType !== "sale" && txType !== "sale_return") return Number(txAmount) || 0;
    if (!stitch || !rate || !gazz) return 0;
    const one = calcOneGazPrice(Number(stitch), Number(rate));
    return one * (Number(gazz) || 0);
  }, [txType, stitch, rate, gazz, txAmount]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = txType === "payment" ? Number(txAmount) : computedAmount;
    if (!amount || amount <= 0) {
      alert("Please enter a valid amount.");
      return;
    }
    const laceItem =
      (txType === "sale" || txType === "sale_return") && stockId !== "none"
        ? data.stock.find((s) => s.id === stockId)
        : undefined;

    const created = onAddTransaction({
      partyId: party.id,
      type: txType,
      amount,
      description:
        txDesc.trim() ||
        (txType === "sale"
          ? "Lace purchase"
          : txType === "sale_return"
            ? "Sale return"
            : txType === "payment"
              ? "Payment received"
              : "Adjustment"),
      paymentMethod: txType === "payment" ? paymentMethod : undefined,
      laceName:
        txType === "sale" || txType === "sale_return"
          ? (laceName || laceItem?.name || "Lace")
          : undefined,
      stitch: (txType === "sale" || txType === "sale_return") && stitch ? Number(stitch) : undefined,
      rate: (txType === "sale" || txType === "sale_return") && rate ? Number(rate) : undefined,
      gazz: (txType === "sale" || txType === "sale_return") && gazz ? Number(gazz) : undefined,
      unitPrice:
        (txType === "sale" || txType === "sale_return") && stitch && rate
          ? calcOneGazPrice(Number(stitch), Number(rate))
          : undefined,
      date: new Date(txDate).toISOString(),
    });

    // Reduce stock for lace sales linked to a stock item (sale_return handled in store)
    if (laceItem && txType === "sale" && gazz) {
      const newQty = Math.max(0, laceItem.quantityGaz - Number(gazz));
      onUpdateStock(laceItem.id, { quantityGaz: newQty });
    }

    resetForm();
    setShowTx(false);
    setReceiptTx(created);
  };

  const sendReminder = () => {
    const phone = party.phone;
    if (!phone) {
      alert("This party has no mobile number. Please add one to send a reminder.");
      return;
    }
    const msg = `Assalam o Alaikum ${party.name},\n\nAapke account ka current balance: *${formatCurrency(bal, data.settings.currency)}* hai (OMITEK Embroidery).\n\nMeharbani farma kar payment clear kar dein. Jazak Allah.\n\n- ${data.settings.shopName}`;
    const url = `https://wa.me/${normalizePhone(phone)}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 flex-wrap">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-1" /> All Parties
        </Button>
        <div className="ml-auto flex gap-2">
          <Button variant="outline" size="sm" onClick={() => exportPartyLedgerPDF(party, data.transactions, data)}>
            <FileDown className="h-4 w-4 mr-1" /> PDF
          </Button>
          {party.phone && bal > 0 && (
            <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white" onClick={sendReminder}>
              <MessageCircle className="h-4 w-4 mr-1" /> WhatsApp Reminder
            </Button>
          )}
        </div>
      </div>

      {/* Header card */}
      <Card>
        <CardContent className="p-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold">{party.name}</h2>
              <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                {party.phone && (
                  <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {party.phone}</span>
                )}
                {party.address && (
                  <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {party.address}</span>
                )}
                <span>Customer since {formatDateTime(party.createdAt)}</span>
              </div>
              {party.notes && (
                <div className="text-sm mt-2 text-muted-foreground">Notes: {party.notes}</div>
              )}
            </div>
            <div className="flex flex-col items-end">
              <div className="text-sm text-muted-foreground">Current Balance</div>
              <div className={`text-3xl font-extrabold ${bal > 0 ? "text-red-600" : bal < 0 ? "text-emerald-600" : "text-muted-foreground"}`}>
                {formatCurrency(Math.abs(bal), data.settings.currency)}
              </div>
              <div className="text-xs text-muted-foreground">
                {bal > 0 ? "Customer owes you" : bal < 0 ? "Advance payment" : "Settled"}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stat row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-amber-100 dark:bg-amber-900/40 p-2.5">
              <ShoppingCart className="h-5 w-5 text-amber-600" />
            </div>
            <div className="min-w-0">
              <div className="text-xs text-muted-foreground">Total Sales</div>
              <div className="font-bold truncate">{formatCurrency(sales, data.settings.currency)}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-emerald-100 dark:bg-emerald-900/40 p-2.5">
              <Wallet className="h-5 w-5 text-emerald-600" />
            </div>
            <div className="min-w-0">
              <div className="text-xs text-muted-foreground">Received</div>
              <div className="font-bold truncate">{formatCurrency(paid, data.settings.currency)}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-blue-100 dark:bg-blue-900/40 p-2.5">
              <RotateCcw className="h-5 w-5 text-blue-600" />
            </div>
            <div className="min-w-0">
              <div className="text-xs text-muted-foreground">Returns</div>
              <div className="font-bold truncate">{formatCurrency(returns, data.settings.currency)}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className={`rounded-full p-2.5 ${bal > 0 ? "bg-red-100 dark:bg-red-900/40" : "bg-slate-100 dark:bg-slate-800"}`}>
              <Scale className={`h-5 w-5 ${bal > 0 ? "text-red-600" : "text-muted-foreground"}`} />
            </div>
            <div className="min-w-0">
              <div className="text-xs text-muted-foreground">Balance</div>
              <div className="font-bold truncate">{formatCurrency(bal, data.settings.currency)}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Transaction History</h3>
        <Button onClick={() => setShowTx(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <Plus className="mr-1 h-4 w-4" /> New Transaction
        </Button>
      </div>

      {partyTx.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">
            No transactions yet for this party. Click “New Transaction” to record a sale, payment or return.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead className="text-right">Debit (+)</TableHead>
                    <TableHead className="text-right">Credit (-)</TableHead>
                    <TableHead className="text-right">Balance</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {partyTx.map((t) => {
                    const isDebit = t.type === "sale" || t.type === "opening";
                    return (
                      <TableRow key={t.id}>
                        <TableCell className="text-sm whitespace-nowrap">{formatDateTime(t.date)}</TableCell>
                        <TableCell>
                          {t.type === "sale" && <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 hover:bg-amber-100">Sale</Badge>}
                          {t.type === "payment" && <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 hover:bg-emerald-100">Payment</Badge>}
                          {t.type === "sale_return" && <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300 hover:bg-blue-100">Return</Badge>}
                          {t.type === "opening" && <Badge variant="secondary">Opening</Badge>}
                        </TableCell>
                        <TableCell className="text-sm max-w-xs">
                          <div className="truncate">{t.description}</div>
                          {t.laceName && (
                            <div className="text-xs text-muted-foreground">
                              {t.laceName}
                              {t.gazz ? ` · ${t.gazz} Gaz` : ""}
                              {t.paymentMethod ? ` · ${t.paymentMethod}` : ""}
                            </div>
                          )}
                          {t.type === "payment" && t.paymentMethod && !t.laceName && (
                            <div className="text-xs text-muted-foreground">via {t.paymentMethod}</div>
                          )}
                        </TableCell>
                        <TableCell className="text-right font-mono">
                          {isDebit ? formatCurrency(t.amount, data.settings.currency) : "—"}
                        </TableCell>
                        <TableCell className="text-right font-mono">
                          {!isDebit ? formatCurrency(t.amount, data.settings.currency) : "—"}
                        </TableCell>
                        <TableCell className="text-right font-mono font-semibold">
                          {formatCurrency(withRunning.get(t.id) || 0, data.settings.currency)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" onClick={() => setReceiptTx(t)} title="View receipt">
                              <Printer className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                if (confirm("Delete this transaction? This cannot be undone.")) {
                                  onDeleteTransaction(t.id);
                                }
                              }}
                              title="Delete"
                            >
                              <Trash2 className="h-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* New transaction dialog */}
      <Dialog open={showTx} onOpenChange={setShowTx}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New Transaction — {party.name}</DialogTitle>
            <DialogDescription>
              Record a sale, payment, or sale return.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              <Button
                type="button"
                variant={txType === "sale" ? "default" : "outline"}
                className={txType === "sale" ? "bg-amber-600 hover:bg-amber-700 text-white" : ""}
                onClick={() => setTxType("sale")}
              >
                <ArrowUpCircle className="mr-1 h-4 w-4" /> Sale
              </Button>
              <Button
                type="button"
                variant={txType === "payment" ? "default" : "outline"}
                className={txType === "payment" ? "bg-emerald-600 hover:bg-emerald-700 text-white" : ""}
                onClick={() => setTxType("payment")}
              >
                <ArrowDownCircle className="mr-1 h-4 w-4" /> Payment
              </Button>
              <Button
                type="button"
                variant={txType === "sale_return" ? "default" : "outline"}
                className={txType === "sale_return" ? "bg-blue-600 hover:bg-blue-700 text-white" : ""}
                onClick={() => setTxType("sale_return")}
              >
                <RotateCcw className="mr-1 h-4 w-4" /> Return
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="txdate">Date & Time</Label>
                <Input
                  id="txdate"
                  type="datetime-local"
                  value={txDate}
                  onChange={(e) => setTxDate(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="txdesc">Description</Label>
                <Input
                  id="txdesc"
                  value={txDesc}
                  onChange={(e) => setTxDesc(e.target.value)}
                  placeholder={txType === "sale" ? "Lace purchase" : txType === "sale_return" ? "Returned lace" : "Payment received"}
                />
              </div>
            </div>

            {txType === "payment" && (
              <div className="space-y-1">
                <Label>Payment Method</Label>
                <Select value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PAYMENT_METHODS.map((m) => (
                      <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {(txType === "sale" || txType === "sale_return") && (
              <div className="space-y-3 rounded-md border p-3 bg-amber-50/50 dark:bg-amber-950/20">
                <div className="text-sm font-medium">Lace details</div>
                <div className="space-y-1">
                  <Label htmlFor="stock">Link to stock (auto-fills)</Label>
                  <Select value={stockId} onValueChange={(v) => {
                    setStockId(v);
                    if (v !== "none") {
                      const item = data.stock.find((s) => s.id === v);
                      if (item) {
                        setLaceName(item.name);
                        setStitch(String(item.stitch));
                        setRate(String(item.rate));
                      }
                    }
                  }}>
                    <SelectTrigger id="stock"><SelectValue placeholder="None — type manually" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None — type manually</SelectItem>
                      {data.stock.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name} ({s.quantityGaz} Gaz in stock)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="lname">Lace Name</Label>
                    <Input id="lname" value={laceName} onChange={(e) => setLaceName(e.target.value)} placeholder="Lace" />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="lstitch">Stitch</Label>
                    <Input id="lstitch" inputMode="decimal" value={stitch} onChange={(e) => setStitch(e.target.value)} placeholder="1200" />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="lrate">Rate</Label>
                    <Input id="lrate" inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="5" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="lgaz">Quantity (Gaz)</Label>
                    <Input id="lgaz" inputMode="decimal" value={gazz} onChange={(e) => setGazz(e.target.value)} placeholder="22" />
                  </div>
                  <div className="space-y-1">
                    <Label>Computed total</Label>
                    <div className="h-9 rounded-md border bg-white dark:bg-background flex items-center px-3 font-bold text-amber-700 dark:text-amber-300">
                      {formatCurrency(computedAmount, data.settings.currency)}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Formula: One Gaz = (Stitch × Rate) ÷ 1000. Total = One Gaz × Quantity.
                  {txType === "sale_return" && " Sale return restores stock automatically."}
                </p>
              </div>
            )}

            {txType === "payment" && (
              <div className="space-y-1">
                <Label htmlFor="pamt">Amount Received</Label>
                <Input
                  id="pamt"
                  inputMode="decimal"
                  required
                  value={txAmount}
                  onChange={(e) => setTxAmount(e.target.value)}
                  placeholder="0"
                />
              </div>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowTx(false)}>Cancel</Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">
                Save & Generate Receipt
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ReceiptModal
        open={!!receiptTx}
        onOpenChange={(o) => !o && setReceiptTx(null)}
        transaction={receiptTx}
        party={party}
        data={data}
      />
    </div>
  );
}

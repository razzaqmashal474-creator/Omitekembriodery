"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, Package, AlertTriangle, SlidersHorizontal, Barcode } from "lucide-react";
import { LaceStockItem, StockAdjustmentType } from "@/lib/types";
import { calcOneGazPrice, calcPiecePrice, formatCurrency, formatDateTime } from "@/lib/format";

interface StockProps {
  stock: LaceStockItem[];
  adjustments: { id: string; stockId: string; type: StockAdjustmentType; quantity: number; reason: string; date: string }[];
  currency: string;
  onAdd: (input: Omit<LaceStockItem, "id" | "createdAt">) => LaceStockItem;
  onUpdate: (id: string, patch: Partial<LaceStockItem>) => void;
  onDelete: (id: string) => void;
  onAdjust: (input: { stockId: string; type: StockAdjustmentType; quantity: number; reason: string }) => void;
  onLookupBarcode: (code: string) => void;
}

export default function Stock({ stock, adjustments, currency, onAdd, onUpdate, onDelete, onAdjust, onLookupBarcode }: StockProps) {
  const [open, setOpen] = useState(false);
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [adjustStockId, setAdjustStockId] = useState("");
  const [adjustType, setAdjustType] = useState<StockAdjustmentType>("add");
  const [adjustQty, setAdjustQty] = useState("");
  const [adjustReason, setAdjustReason] = useState("");
  const [barcodeLookup, setBarcodeLookup] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [color, setColor] = useState("");
  const [stitch, setStitch] = useState("");
  const [rate, setRate] = useState("");
  const [costPerGaz, setCostPerGaz] = useState("");
  const [qty, setQty] = useState("");
  const [reorder, setReorder] = useState("");
  const [barcode, setBarcode] = useState("");

  const openForm = (item?: LaceStockItem) => {
    if (item) {
      setEditId(item.id);
      setName(item.name);
      setColor(item.color || "");
      setStitch(String(item.stitch));
      setRate(String(item.rate));
      setCostPerGaz(item.costPerGaz ? String(item.costPerGaz) : "");
      setQty(String(item.quantityGaz));
      setReorder(item.reorderLevel ? String(item.reorderLevel) : "");
      setBarcode(item.barcode || "");
    } else {
      setEditId(null);
      setName("");
      setColor("");
      setStitch("");
      setRate("");
      setCostPerGaz("");
      setQty("");
      setReorder("");
      setBarcode("");
    }
    setOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !stitch || !rate) {
      alert("Please enter name, stitch and rate.");
      return;
    }
    const payload = {
      name: name.trim(),
      color: color.trim() || undefined,
      stitch: Number(stitch) || 0,
      rate: Number(rate) || 0,
      costPerGaz: costPerGaz ? Number(costPerGaz) : undefined,
      quantityGaz: Number(qty) || 0,
      reorderLevel: reorder ? Number(reorder) : undefined,
      barcode: barcode.trim() || undefined,
    };
    if (editId) {
      onUpdate(editId, payload);
    } else {
      onAdd(payload);
    }
    setOpen(false);
  };

  const handleAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustStockId || !adjustQty) {
      alert("Select stock and enter quantity.");
      return;
    }
    onAdjust({
      stockId: adjustStockId,
      type: adjustType,
      quantity: Number(adjustQty),
      reason: adjustReason.trim() || "Manual adjustment",
    });
    setAdjustStockId("");
    setAdjustQty("");
    setAdjustReason("");
    setAdjustOpen(false);
  };

  const handleBarcodeLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeLookup.trim()) return;
    onLookupBarcode(barcodeLookup.trim());
    setBarcodeLookup("");
  };

  const itemAdjustments = adjustStockId
    ? adjustments.filter((a) => a.stockId === adjustStockId).slice(0, 8)
    : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Package className="h-6 w-6 text-emerald-600" /> Lace Stock
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Manage inventory. Cost price drives Profit &amp; Loss. Sale rate drives customer billing.
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={() => setAdjustOpen(true)}>
            <SlidersHorizontal className="mr-2 h-4 w-4" /> Adjust
          </Button>
          <Button onClick={() => openForm()} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            <Plus className="mr-2 h-4 w-4" /> Add Lace
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-3">
          <form onSubmit={handleBarcodeLookup} className="flex gap-2 items-end">
            <div className="flex-1 space-y-1">
              <Label htmlFor="barcode" className="text-xs flex items-center gap-1">
                <Barcode className="h-3 w-3" /> Scan / enter barcode to find lace
              </Label>
              <Input
                id="barcode"
                value={barcodeLookup}
                onChange={(e) => setBarcodeLookup(e.target.value)}
                placeholder="Scan or type barcode..."
                autoFocus
              />
            </div>
            <Button type="submit" variant="outline">Lookup</Button>
          </form>
        </CardContent>
      </Card>

      {stock.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            No lace in stock yet. Click “Add Lace” to add your first item.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Lace</TableHead>
                    <TableHead>Stitch</TableHead>
                    <TableHead>Cost/Gaz</TableHead>
                    <TableHead>Sale Rate</TableHead>
                    <TableHead className="text-right">One Gaz</TableHead>
                    <TableHead className="text-right">1 Piece</TableHead>
                    <TableHead className="text-right">In Stock</TableHead>
                    <TableHead className="text-right">Value</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stock.map((s) => {
                    const one = calcOneGazPrice(s.stitch, s.rate);
                    const piece = calcPiecePrice(s.stitch, s.rate);
                    const cost = s.costPerGaz ?? 0;
                    const value = cost * s.quantityGaz;
                    const profit = one - cost;
                    const lowStock = s.reorderLevel != null && s.quantityGaz <= s.reorderLevel;
                    return (
                      <TableRow key={s.id}>
                        <TableCell>
                          <div className="font-medium">{s.name}</div>
                          {s.color && <div className="text-xs text-muted-foreground">{s.color}</div>}
                          {s.barcode && <div className="text-xs text-muted-foreground font-mono">{s.barcode}</div>}
                        </TableCell>
                        <TableCell className="font-mono">{s.stitch}</TableCell>
                        <TableCell className="font-mono text-xs">{cost ? formatCurrency(cost, currency) : "—"}</TableCell>
                        <TableCell className="font-mono">{s.rate}</TableCell>
                        <TableCell className="text-right font-mono">{formatCurrency(one, currency)}</TableCell>
                        <TableCell className="text-right font-mono">{formatCurrency(piece, currency)}</TableCell>
                        <TableCell className="text-right">
                          <span className={`font-mono ${lowStock ? "text-red-600 font-bold" : ""}`}>{s.quantityGaz}</span>
                          {lowStock && (
                            <Badge variant="destructive" className="ml-2 text-xs">
                              <AlertTriangle className="h-3 w-3 mr-1" /> Low
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right font-mono">{formatCurrency(value, currency)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" onClick={() => openForm(s)} title="Edit">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => {
                              if (confirm(`Delete "${s.name}" from stock?`)) onDelete(s.id);
                            }} title="Delete">
                              <Trash2 className="h-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Lace" : "Add Lace"}</DialogTitle>
            <DialogDescription>
              Sale rate drives customer price: One Gaz = (Stitch × Rate) ÷ 1000.
              Cost/Gaz is the purchase price — used for profit calculation.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="sname">Lace Name *</Label>
              <Input id="sname" required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Fancy Net Lace" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="scolor">Color / Variant</Label>
                <Input id="scolor" value={color} onChange={(e) => setColor(e.target.value)} placeholder="e.g. White" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="sbar">Barcode</Label>
                <Input id="sbar" value={barcode} onChange={(e) => setBarcode(e.target.value)} placeholder="Scan or type" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="sstitch">Stitch *</Label>
                <Input id="sstitch" required inputMode="decimal" value={stitch} onChange={(e) => setStitch(e.target.value)} placeholder="1200" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="srate">Sale Rate *</Label>
                <Input id="srate" required inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="5" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label htmlFor="scost">Cost / Gaz</Label>
                <Input id="scost" inputMode="decimal" value={costPerGaz} onChange={(e) => setCostPerGaz(e.target.value)} placeholder="3" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="sqty">Quantity (Gaz)</Label>
                <Input id="sqty" inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="0" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="sreorder">Reorder Lvl</Label>
                <Input id="sreorder" inputMode="decimal" value={reorder} onChange={(e) => setReorder(e.target.value)} placeholder="10" />
              </div>
            </div>
            {stitch && rate && (
              <div className="rounded-md bg-emerald-50 dark:bg-emerald-950/30 p-3 text-sm space-y-1">
                <div className="flex justify-between"><span className="text-muted-foreground">One Gaz sale price:</span><span className="font-bold text-emerald-700 dark:text-emerald-300">{formatCurrency(calcOneGazPrice(Number(stitch), Number(rate)), currency)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">One piece (×22):</span><span className="font-bold text-emerald-700 dark:text-emerald-300">{formatCurrency(calcPiecePrice(Number(stitch), Number(rate)), currency)}</span></div>
                {costPerGaz && (
                  <div className="flex justify-between"><span className="text-muted-foreground">Profit / Gaz:</span><span className="font-bold text-emerald-700 dark:text-emerald-300">{formatCurrency(calcOneGazPrice(Number(stitch), Number(rate)) - Number(costPerGaz), currency)}</span></div>
                )}
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">{editId ? "Update" : "Add"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Stock adjustment dialog */}
      <Dialog open={adjustOpen} onOpenChange={setAdjustOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Stock Adjustment</DialogTitle>
            <DialogDescription>
              Manually add, reduce, or set quantity. Useful for damaged stock, miscounts, or sample cuts.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAdjust} className="space-y-3">
            <div className="space-y-1">
              <Label>Lace Item *</Label>
              <Select value={adjustStockId} onValueChange={setAdjustStockId}>
                <SelectTrigger><SelectValue placeholder="Select lace" /></SelectTrigger>
                <SelectContent>
                  {stock.map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.name} ({s.quantityGaz} Gaz)</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Action</Label>
                <Select value={adjustType} onValueChange={(v) => setAdjustType(v as StockAdjustmentType)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="add">Add (+)</SelectItem>
                    <SelectItem value="reduce">Reduce (-)</SelectItem>
                    <SelectItem value="set">Set exact</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Quantity (Gaz)</Label>
                <Input inputMode="decimal" required value={adjustQty} onChange={(e) => setAdjustQty(e.target.value)} placeholder="0" />
              </div>
            </div>
            <div className="space-y-1">
              <Label>Reason</Label>
              <Input value={adjustReason} onChange={(e) => setAdjustReason(e.target.value)} placeholder="e.g. Damaged / recount" />
            </div>
            {itemAdjustments.length > 0 && (
              <div className="rounded-md border p-2 max-h-40 overflow-y-auto">
                <div className="text-xs font-medium text-muted-foreground mb-1">Recent adjustments for this item</div>
                {itemAdjustments.map((a) => (
                  <div key={a.id} className="text-xs flex justify-between border-b last:border-0 py-1">
                    <span>{formatDateTime(a.date)} · {a.type} {a.quantity}</span>
                    <span className="text-muted-foreground truncate ml-2">{a.reason}</span>
                  </div>
                ))}
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setAdjustOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">Apply</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

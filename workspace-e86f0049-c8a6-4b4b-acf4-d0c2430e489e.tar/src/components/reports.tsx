"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
  LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
} from "recharts";
import { Download, FileSpreadsheet, FileText, TrendingUp, TrendingDown, DollarSign, Percent } from "lucide-react";
import { AppData } from "@/lib/types";
import { partyBalance } from "@/lib/store";
import { formatCurrency, formatDate, isSameDay, isSameMonth, todayISO } from "@/lib/format";
import { exportDataToExcel, exportProfitLossPDF } from "@/lib/export";

interface ReportsProps {
  data: AppData;
}

const COLORS = ["#10b981", "#f59e0b", "#ef4444", "#3b82f6", "#8b5cf6", "#ec4899"];

export default function Reports({ data }: ReportsProps) {
  const [period, setPeriod] = useState<"today" | "month" | "all">("month");
  const now = todayISO();

  const inPeriod = (d: string) => {
    if (period === "today") return isSameDay(d, now);
    if (period === "month") return isSameMonth(d, now);
    return true;
  };

  const filteredTx = data.transactions.filter((t) => inPeriod(t.date));
  const filteredExp = data.expenses.filter((e) => inPeriod(e.date));
  const filteredPur = data.purchases.filter((p) => inPeriod(p.date));

  const totalSales = filteredTx.filter((t) => t.type === "sale").reduce((s, t) => s + t.amount, 0);
  const totalReturns = filteredTx.filter((t) => t.type === "sale_return").reduce((s, t) => s + t.amount, 0);
  const totalRecv = filteredTx.filter((t) => t.type === "payment").reduce((s, t) => s + t.amount, 0);
  const totalExp = filteredExp.reduce((s, e) => s + e.amount, 0);
  const totalPur = filteredPur.reduce((s, p) => s + p.amountPaid, 0);

  // COGS
  const cogs = (() => {
    let sum = 0;
    filteredTx
      .filter((t) => t.type === "sale" && t.laceName)
      .forEach((t) => {
        const stockItem = data.stock.find((s) => s.name === t.laceName);
        const cost = stockItem?.costPerGaz ?? 0;
        sum += cost * (t.gazz || 0);
      });
    return sum;
  })();

  const netSales = totalSales - totalReturns;
  const grossProfit = netSales - cogs;
  const netProfit = grossProfit - totalExp;
  const profitMargin = netSales > 0 ? (netProfit / netSales) * 100 : 0;

  // Last 30 days trend
  const last30 = useMemo(() => {
    const days: { label: string; sales: number; payments: number; expenses: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString();
      const dayLabel = d.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
      const sales = data.transactions.filter((t) => t.type === "sale" && isSameDay(t.date, key)).reduce((s, t) => s + t.amount, 0);
      const returns = data.transactions.filter((t) => t.type === "sale_return" && isSameDay(t.date, key)).reduce((s, t) => s + t.amount, 0);
      const payments = data.transactions.filter((t) => t.type === "payment" && isSameDay(t.date, key)).reduce((s, t) => s + t.amount, 0);
      const expenses = data.expenses.filter((e) => isSameDay(e.date, key)).reduce((s, e) => s + e.amount, 0);
      days.push({ label: dayLabel, sales: sales - returns, payments, expenses });
    }
    return days;
  }, [data.transactions, data.expenses]);

  // Monthly comparison (last 6 months)
  const last6Months = useMemo(() => {
    const months: { label: string; sales: number; expenses: number; profit: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const monthKey = d.toISOString();
      const label = d.toLocaleDateString("en-GB", { month: "short" });
      const tx = data.transactions.filter((t) => {
        const td = new Date(t.date);
        return td.getMonth() === d.getMonth() && td.getFullYear() === d.getFullYear();
      });
      const sales = tx.filter((t) => t.type === "sale").reduce((s, t) => s + t.amount, 0)
        - tx.filter((t) => t.type === "sale_return").reduce((s, t) => s + t.amount, 0);
      const exp = data.expenses.filter((e) => {
        const ed = new Date(e.date);
        return ed.getMonth() === d.getMonth() && ed.getFullYear() === d.getFullYear();
      }).reduce((s, e) => s + e.amount, 0);
      months.push({ label, sales, expenses: exp, profit: sales - exp });
    }
    return months;
  }, [data.transactions, data.expenses]);

  // Top selling lace
  const topLaces = useMemo(() => {
    const map = new Map<string, number>();
    data.transactions
      .filter((t) => t.type === "sale" && t.laceName)
      .forEach((t) => {
        const k = t.laceName as string;
        map.set(k, (map.get(k) || 0) + t.amount);
      });
    return [...map.entries()].map(([name, amount]) => ({ name, amount })).sort((a, b) => b.amount - a.amount).slice(0, 6);
  }, [data.transactions]);

  // Payment methods breakdown
  const methodBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    data.transactions
      .filter((t) => t.type === "payment" && t.paymentMethod)
      .forEach((t) => {
        const k = t.paymentMethod as string;
        map.set(k, (map.get(k) || 0) + t.amount);
      });
    return [...map.entries()].map(([name, value]) => ({ name, value }));
  }, [data.transactions]);

  // Top debtors
  const topDebtors = useMemo(
    () => data.parties
      .map((p) => ({ name: p.name, balance: partyBalance(p.id, data.transactions) }))
      .filter((x) => x.balance > 0)
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 5),
    [data.parties, data.transactions],
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-emerald-600" /> Reports & Analytics
          </h2>
          <p className="text-muted-foreground text-sm mt-1">P&L statement, advanced charts, exports.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => exportDataToExcel(data)}>
            <FileSpreadsheet className="mr-2 h-4 w-4" /> Excel
          </Button>
          <Button variant="outline" onClick={() => exportProfitLossPDF(data, period)}>
            <FileText className="mr-2 h-4 w-4" /> P&L PDF
          </Button>
        </div>
      </div>

      <Tabs value={period} onValueChange={(v) => setPeriod(v as typeof period)}>
        <TabsList>
          <TabsTrigger value="today">Today</TabsTrigger>
          <TabsTrigger value="month">This Month</TabsTrigger>
          <TabsTrigger value="all">All Time</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* P&L Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Profit & Loss Statement ({period})</CardTitle>
          <CardDescription>Net profit = Net Sales − COGS − Expenses.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Row label="Gross Sales" value={totalSales} currency={data.settings.currency} />
          <Row label="(−) Sale Returns" value={-totalReturns} currency={data.settings.currency} />
          <Row label="Net Sales" value={netSales} currency={data.settings.currency} bold border />
          <Row label="(−) Cost of Goods Sold (COGS)" value={-cogs} currency={data.settings.currency} />
          <Row label="Gross Profit" value={grossProfit} currency={data.settings.currency} bold border color={grossProfit >= 0 ? "emerald" : "red"} />
          <Row label="(−) Operating Expenses" value={-totalExp} currency={data.settings.currency} />
          <Row label="Net Profit" value={netProfit} currency={data.settings.currency} bold border color={netProfit >= 0 ? "emerald" : "red"} />
          <div className="flex justify-between items-center p-3 rounded-md bg-muted/40 mt-2">
            <span className="text-sm flex items-center gap-1"><Percent className="h-3 w-3" /> Profit Margin</span>
            <span className={`font-bold ${profitMargin >= 0 ? "text-emerald-600" : "text-red-600"}`}>
              {profitMargin.toFixed(1)}%
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Sales</div>
            <div className="text-xl font-bold text-amber-600">{formatCurrency(totalSales, data.settings.currency)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Received</div>
            <div className="text-xl font-bold text-emerald-600">{formatCurrency(totalRecv, data.settings.currency)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Expenses</div>
            <div className="text-xl font-bold text-red-600">{formatCurrency(totalExp, data.settings.currency)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Purchases</div>
            <div className="text-xl font-bold text-blue-600">{formatCurrency(totalPur, data.settings.currency)}</div>
          </CardContent>
        </Card>
      </div>

      {/* 30-day area chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">30-Day Trend — Sales, Payments, Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={last30}>
                <defs>
                  <linearGradient id="cs" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="cp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="ce" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="label" fontSize={11} interval={3} />
                <YAxis fontSize={11} width={70} />
                <Tooltip formatter={(v: number) => formatCurrency(v, data.settings.currency)} />
                <Legend />
                <Area type="monotone" dataKey="sales" stroke="#f59e0b" fill="url(#cs)" name="Sales" />
                <Area type="monotone" dataKey="payments" stroke="#10b981" fill="url(#cp)" name="Payments" />
                <Area type="monotone" dataKey="expenses" stroke="#ef4444" fill="url(#ce)" name="Expenses" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* 6-month comparison */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">6-Month Comparison</CardTitle>
            <CardDescription>Monthly sales, expenses & profit.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={last6Months}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="label" fontSize={11} />
                  <YAxis fontSize={11} width={70} />
                  <Tooltip formatter={(v: number) => formatCurrency(v, data.settings.currency)} />
                  <Legend />
                  <Bar dataKey="sales" name="Sales" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expenses" name="Expenses" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="profit" name="Profit" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Payment methods pie */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Payment Methods Received</CardTitle>
            <CardDescription>All-time breakdown by method.</CardDescription>
          </CardHeader>
          <CardContent>
            {methodBreakdown.length === 0 ? (
              <div className="text-center text-muted-foreground py-12 text-sm">No payments received yet.</div>
            ) : (
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={methodBreakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                      {methodBreakdown.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: number) => formatCurrency(v, data.settings.currency)} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top laces */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Top Selling Lace</CardTitle>
          </CardHeader>
          <CardContent>
            {topLaces.length === 0 ? (
              <div className="text-center text-muted-foreground py-6 text-sm">No lace sales yet.</div>
            ) : (
              <div className="space-y-3">
                {topLaces.map((l, i) => {
                  const max = topLaces[0].amount || 1;
                  return (
                    <div key={l.name}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-medium">{i + 1}. {l.name}</span>
                        <span className="font-mono">{formatCurrency(l.amount, data.settings.currency)}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${(l.amount / max) * 100}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top debtors */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><DollarSign className="h-4 w-4 text-red-500" /> Top Outstanding Balances</CardTitle>
          </CardHeader>
          <CardContent>
            {topDebtors.length === 0 ? (
              <div className="text-center text-muted-foreground py-6 text-sm">No outstanding balances.</div>
            ) : (
              <div className="space-y-2">
                {topDebtors.map((d, i) => (
                  <div key={d.name} className="flex justify-between items-center p-2 rounded-md hover:bg-muted">
                    <span className="text-sm"><span className="text-muted-foreground">{i + 1}.</span> {d.name}</span>
                    <span className="font-mono text-sm font-bold text-red-600">{formatCurrency(d.balance, data.settings.currency)}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Row({
  label, value, currency, bold, border, color,
}: { label: string; value: number; currency: string; bold?: boolean; border?: boolean; color?: "emerald" | "red" }) {
  const colorClass = color === "emerald" ? "text-emerald-600" : color === "red" ? "text-red-600" : "";
  return (
    <div className={`flex justify-between items-center ${border ? "border-t pt-2 mt-1" : ""}`}>
      <span className={`text-sm ${bold ? "font-semibold" : ""}`}>{label}</span>
      <span className={`font-mono ${bold ? "font-bold" : ""} ${colorClass}`}>
        {formatCurrency(value, currency)}
      </span>
    </div>
  );
}

"use client";

import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Users, ShoppingCart, Wallet, TrendingDown, Scale, Package, AlertTriangle, ArrowRight,
  Truck, DollarSign, Bell,
} from "lucide-react";
import { AppData } from "@/lib/types";
import { partyBalance } from "@/lib/store";
import { formatCurrency, formatDateTime, isSameDay, isSameMonth, todayISO } from "@/lib/format";

interface DashboardProps {
  data: AppData;
  onNavigate: (tab: string) => void;
  onOpenParty: (id: string) => void;
}

export default function Dashboard({ data, onNavigate, onOpenParty }: DashboardProps) {
  const now = todayISO();

  const totalSales = data.transactions.filter((t) => t.type === "sale").reduce((s, t) => s + t.amount, 0);
  const totalReturns = data.transactions.filter((t) => t.type === "sale_return").reduce((s, t) => s + t.amount, 0);
  const totalReceived = data.transactions.filter((t) => t.type === "payment").reduce((s, t) => s + t.amount, 0);
  const totalOutstanding = data.parties.reduce((s, p) => s + Math.max(0, partyBalance(p.id, data.transactions)), 0);
  const totalExpenses = data.expenses.reduce((s, e) => s + e.amount, 0);
  const monthExpenses = data.expenses.filter((e) => isSameMonth(e.date, now)).reduce((s, e) => s + e.amount, 0);
  const monthSales = data.transactions.filter((t) => t.type === "sale" && isSameMonth(t.date, now)).reduce((s, t) => s + t.amount, 0);
  const todaySales = data.transactions.filter((t) => t.type === "sale" && isSameDay(t.date, now)).reduce((s, t) => s + t.amount, 0);
  const todayTxCount = data.transactions.filter((t) => isSameDay(t.date, now)).length;

  // COGS for the period
  const cogsAll = useMemo(() => {
    let sum = 0;
    data.transactions
      .filter((t) => t.type === "sale" && t.laceName)
      .forEach((t) => {
        const stockItem = data.stock.find((s) => s.name === t.laceName);
        const cost = stockItem?.costPerGaz ?? 0;
        sum += cost * (t.gazz || 0);
      });
    return sum;
  }, [data.transactions, data.stock]);

  const netProfit = totalSales - totalReturns - cogsAll - totalExpenses;
  const totalSupplierBal = data.suppliers.reduce(
    (s, sup) => s + Math.max(0, (sup.openingBalance || 0) + data.purchases
      .filter((p) => p.supplierId === sup.id)
      .reduce((x, p) => x + (p.totalAmount - p.amountPaid), 0)),
    0,
  );

  const lowStock = data.stock.filter((s) => s.reorderLevel != null && s.quantityGaz <= (s.reorderLevel || 0));
  const stockValue = data.stock.reduce(
    (s, item) => s + (item.costPerGaz ?? (item.stitch * item.rate) / 1000) * item.quantityGaz,
    0,
  );

  const recentTx = useMemo(
    () => [...data.transactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 6),
    [data.transactions],
  );

  const topDebtors = useMemo(
    () => data.parties
      .map((p) => ({ party: p, balance: partyBalance(p.id, data.transactions) }))
      .filter((x) => x.balance > 0)
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 5),
    [data.parties, data.transactions],
  );

  const stats = [
    { label: "Total Customers", value: String(data.parties.length), icon: Users, color: "emerald", tab: "parties" },
    { label: "Total Sales", value: formatCurrency(totalSales, data.settings.currency), icon: ShoppingCart, color: "amber", tab: "reports" },
    { label: "Total Received", value: formatCurrency(totalReceived, data.settings.currency), icon: Wallet, color: "emerald", tab: "reports" },
    { label: "Outstanding", value: formatCurrency(totalOutstanding, data.settings.currency), icon: Scale, color: "red", tab: "parties" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground text-sm mt-1">
            Welcome to {data.settings.shopName}. Business at a glance.
          </p>
        </div>
        {(lowStock.length > 0 || topDebtors.length > 0) && (
          <Button variant="outline" onClick={() => onNavigate("notifications")} className="relative">
            <Bell className="h-4 w-4 mr-2" /> Alerts
            <Badge variant="destructive" className="ml-2">{lowStock.length + topDebtors.length}</Badge>
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          const colorMap: Record<string, string> = {
            emerald: "bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300",
            amber: "bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300",
            red: "bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300",
          };
          return (
            <Card key={s.label} className="cursor-pointer hover:border-emerald-400 hover:shadow-sm transition" onClick={() => onNavigate(s.tab)}>
              <CardContent className="p-4">
                <div className={`inline-flex rounded-full p-2.5 mb-3 ${colorMap[s.color]}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
                <div className="text-xl font-bold mt-0.5 truncate">{s.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Today&apos;s Sales</div>
            <div className="text-lg font-bold text-amber-600">{formatCurrency(todaySales, data.settings.currency)}</div>
            <div className="text-xs text-muted-foreground">{todayTxCount} transactions</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">This Month Sales</div>
            <div className="text-lg font-bold">{formatCurrency(monthSales, data.settings.currency)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">This Month Expenses</div>
            <div className="text-lg font-bold text-red-600">{formatCurrency(monthExpenses, data.settings.currency)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Net Profit (all time)</div>
            <div className={`text-lg font-bold ${netProfit >= 0 ? "text-emerald-600" : "text-red-600"}`}>
              {formatCurrency(netProfit, data.settings.currency)}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-base">Recent Transactions</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate("parties")}>
              View all <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </CardHeader>
          <CardContent className="pt-0">
            {recentTx.length === 0 ? (
              <div className="text-center text-muted-foreground py-8 text-sm">No transactions yet.</div>
            ) : (
              <div className="space-y-2">
                {recentTx.map((t) => {
                  const p = data.parties.find((x) => x.id === t.partyId);
                  return (
                    <button
                      key={t.id}
                      onClick={() => p && onOpenParty(p.id)}
                      className="w-full flex items-center justify-between p-2 rounded-md hover:bg-muted text-left"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`rounded-full p-1.5 ${
                          t.type === "sale" ? "bg-amber-100 dark:bg-amber-900/40 text-amber-600"
                          : t.type === "payment" ? "bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600"
                          : t.type === "sale_return" ? "bg-blue-100 dark:bg-blue-900/40 text-blue-600"
                          : "bg-muted text-muted-foreground"
                        }`}>
                          {t.type === "sale" ? <ShoppingCart className="h-4 w-4" />
                          : t.type === "payment" ? <Wallet className="h-4 w-4" />
                          : t.type === "sale_return" ? <Scale className="h-4 w-4" />
                          : <DollarSign className="h-4 w-4" />}
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm font-medium truncate">{p?.name || "Unknown"}</div>
                          <div className="text-xs text-muted-foreground truncate">
                            {formatDateTime(t.date)} · {t.description}
                          </div>
                        </div>
                      </div>
                      <div className={`font-mono font-semibold ${
                        t.type === "sale" || t.type === "opening" ? "text-amber-700 dark:text-amber-300"
                        : t.type === "payment" ? "text-emerald-700 dark:text-emerald-300"
                        : "text-blue-700 dark:text-blue-300"
                      }`}>
                        {formatCurrency(t.amount, data.settings.currency)}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Scale className="h-4 w-4 text-red-500" /> Top Outstanding
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {topDebtors.length === 0 ? (
              <div className="text-center text-muted-foreground py-8 text-sm">No outstanding balances. 🎉</div>
            ) : (
              <div className="space-y-2">
                {topDebtors.map((d) => (
                  <button
                    key={d.party.id}
                    onClick={() => onOpenParty(d.party.id)}
                    className="w-full flex items-center justify-between p-2 rounded-md hover:bg-muted text-left"
                  >
                    <span className="text-sm font-medium truncate">{d.party.name}</span>
                    <Badge variant="destructive">{formatCurrency(d.balance, data.settings.currency)}</Badge>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="cursor-pointer hover:border-emerald-400 transition" onClick={() => onNavigate("stock")}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-emerald-100 dark:bg-emerald-900/40 p-2.5">
              <Package className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Stock Value</div>
              <div className="font-bold">{formatCurrency(stockValue, data.settings.currency)}</div>
              <div className="text-xs text-muted-foreground">{data.stock.length} items</div>
            </div>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:border-emerald-400 transition" onClick={() => onNavigate("suppliers")}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-blue-100 dark:bg-blue-900/40 p-2.5">
              <Truck className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Suppliers</div>
              <div className="font-bold">{data.suppliers.length}</div>
              <div className="text-xs text-muted-foreground">Owe: {formatCurrency(totalSupplierBal, data.settings.currency)}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:border-emerald-400 transition" onClick={() => onNavigate("expenses")}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-full bg-red-100 dark:bg-red-900/40 p-2.5">
              <TrendingDown className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Total Expenses</div>
              <div className="font-bold">{formatCurrency(totalExpenses, data.settings.currency)}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:border-emerald-400 transition" onClick={() => onNavigate("notifications")}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className={`rounded-full p-2.5 ${lowStock.length > 0 ? "bg-amber-100 dark:bg-amber-900/40" : "bg-muted"}`}>
              <AlertTriangle className={`h-5 w-5 ${lowStock.length > 0 ? "text-amber-600" : "text-muted-foreground"}`} />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Low Stock Alerts</div>
              <div className="font-bold">{lowStock.length}</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

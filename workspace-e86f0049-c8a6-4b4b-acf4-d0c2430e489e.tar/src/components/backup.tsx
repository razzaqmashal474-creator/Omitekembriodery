"use client";

import { useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import {
  Download, Upload, AlertTriangle, Save, DatabaseBackup, RotateCcw, Settings as SettingsIcon,
  FileSpreadsheet, FileText,
} from "lucide-react";
import { AppData, AppSettings } from "@/lib/types";
import { formatDateTime } from "@/lib/format";
import { exportDataToExcel, exportProfitLossPDF } from "@/lib/export";

interface BackupProps {
  data: AppData;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onReplaceAll: (next: AppData) => void;
  onResetAll: () => void;
}

export default function Backup({ data, onUpdateSettings, onReplaceAll, onResetAll }: BackupProps) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [importText, setImportText] = useState("");
  const [showImport, setShowImport] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [shopName, setShopName] = useState(data.settings.shopName);
  const [shopPhone, setShopPhone] = useState(data.settings.shopPhone);
  const [shopAddress, setShopAddress] = useState(data.settings.shopAddress);
  const [currency, setCurrency] = useState(data.settings.currency);

  const downloadBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `omitek-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string);
        if (!parsed.parties || !parsed.transactions) {
          alert("Invalid backup file.");
          return;
        }
        setImportText(JSON.stringify(parsed, null, 2));
        setShowImport(true);
      } catch {
        alert("Could not parse file.");
      }
    };
    reader.readAsText(file);
  };

  const confirmImport = () => {
    try {
      const parsed = JSON.parse(importText) as AppData;
      if (!Array.isArray(parsed.parties) || !Array.isArray(parsed.transactions)) {
        alert("Invalid data.");
        return;
      }
      onReplaceAll(parsed);
      setShowImport(false);
      setImportText("");
      alert("Backup restored!");
    } catch {
      alert("Invalid JSON.");
    }
  };

  const saveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      shopName: shopName.trim() || "OMITEK Embroidery",
      shopPhone: shopPhone.trim(),
      shopAddress: shopAddress.trim(),
      currency: currency.trim() || "Rs.",
    });
    alert("Settings saved!");
  };

  const counts = {
    parties: data.parties.length,
    transactions: data.transactions.length,
    stock: data.stock.length,
    expenses: data.expenses.length,
    suppliers: data.suppliers.length,
    purchases: data.purchases.length,
    cashClosings: data.cashClosings.length,
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <DatabaseBackup className="h-6 w-6 text-emerald-600" /> Backup, Restore & Settings
        </h2>
        <p className="text-muted-foreground text-sm mt-1">
          Your data lives only on this computer. Export regularly.
        </p>
      </div>

      {/* Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><SettingsIcon className="h-5 w-5" /> Shop Settings</CardTitle>
          <CardDescription>Used on receipts and across the app.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={saveSettings} className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1 md:col-span-2">
              <Label htmlFor="shopname">Shop Name</Label>
              <Input id="shopname" value={shopName} onChange={(e) => setShopName(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="shopphone">Shop Phone</Label>
              <Input id="shopphone" value={shopPhone} onChange={(e) => setShopPhone(e.target.value)} placeholder="03xx-xxxxxxx" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="currency">Currency Symbol</Label>
              <Input id="currency" value={currency} onChange={(e) => setCurrency(e.target.value)} placeholder="Rs." />
            </div>
            <div className="space-y-1 md:col-span-2">
              <Label htmlFor="shopaddr">Shop Address</Label>
              <Input id="shopaddr" value={shopAddress} onChange={(e) => setShopAddress(e.target.value)} />
            </div>
            <div className="md:col-span-2">
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">
                <Save className="mr-2 h-4 w-4" /> Save Settings
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Excel + PDF export */}
      <Card>
        <CardHeader>
          <CardTitle>Excel & PDF Reports</CardTitle>
          <CardDescription>One-click exports of all your data.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-3">
          <Button onClick={() => exportDataToExcel(data)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            <FileSpreadsheet className="mr-2 h-4 w-4" /> Full Excel Export
          </Button>
          <Button variant="outline" onClick={() => exportProfitLossPDF(data, "all")}>
            <FileText className="mr-2 h-4 w-4" /> P&L PDF (all time)
          </Button>
          <Button variant="outline" onClick={() => exportProfitLossPDF(data, "month")}>
            <FileText className="mr-2 h-4 w-4" /> P&L PDF (this month)
          </Button>
        </CardContent>
      </Card>

      {/* Backup */}
      <Card>
        <CardHeader>
          <CardTitle>Backup & Restore</CardTitle>
          <CardDescription>JSON backup of all data.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-md border p-4 bg-muted/30">
            <div className="text-sm font-medium mb-2">Current data on this computer</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <Stat label="Parties" value={counts.parties} />
              <Stat label="Transactions" value={counts.transactions} />
              <Stat label="Stock items" value={counts.stock} />
              <Stat label="Expenses" value={counts.expenses} />
              <Stat label="Suppliers" value={counts.suppliers} />
              <Stat label="Purchases" value={counts.purchases} />
              <Stat label="Cash Closings" value={counts.cashClosings} />
              <Stat label="Staff users" value={data.staff.length} />
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <Button onClick={downloadBackup} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Download className="mr-2 h-4 w-4" /> Download Backup (.json)
            </Button>
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload className="mr-2 h-4 w-4" /> Restore from File
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
                e.target.value = "";
              }}
            />
          </div>

          <div className="rounded-md border border-red-200 bg-red-50 dark:bg-red-950/30 dark:border-red-900 p-4">
            <div className="flex items-center gap-2 font-medium text-red-700 dark:text-red-300">
              <AlertTriangle className="h-4 w-4" /> Danger Zone
            </div>
            <p className="text-sm text-red-700 dark:text-red-300 mt-1 mb-3">
              Reset will permanently delete all data on this computer. Export a backup first!
            </p>
            <Button variant="destructive" onClick={() => setShowReset(true)}>
              <RotateCcw className="mr-2 h-4 w-4" /> Reset All Data
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Import preview */}
      <Dialog open={showImport} onOpenChange={setShowImport}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Confirm Restore</DialogTitle>
            <DialogDescription>This will replace ALL current data.</DialogDescription>
          </DialogHeader>
          <Textarea rows={12} value={importText} onChange={(e) => setImportText(e.target.value)} className="font-mono text-xs" />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImport(false)}>Cancel</Button>
            <Button onClick={confirmImport} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Upload className="mr-2 h-4 w-4" /> Restore Now
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset */}
      <Dialog open={showReset} onOpenChange={setShowReset}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" /> Confirm Reset
            </DialogTitle>
            <DialogDescription>
              This will permanently delete {counts.parties} parties, {counts.transactions} transactions,
              {" "}{counts.stock} stock items, {counts.suppliers} suppliers, and all other data.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReset(false)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { onResetAll(); setShowReset(false); }}>
              Yes, delete everything
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="text-xs text-muted-foreground text-center pb-4">
        All data is stored locally in your browser. Last modified: {formatDateTime(new Date().toISOString())}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded bg-background p-2 border">
      <div className="text-muted-foreground">{label}</div>
      <div className="font-bold">{value}</div>
    </div>
  );
}

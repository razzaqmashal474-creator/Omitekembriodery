"use client";

import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Bell, MessageCircle, Package, Users } from "lucide-react";
import { AppData } from "@/lib/types";
import { partyBalance } from "@/lib/store";
import { formatCurrency, normalizePhone } from "@/lib/format";

interface NotificationsProps {
  data: AppData;
  onOpenParty: (id: string) => void;
  onNavigate: (tab: string) => void;
}

export default function Notifications({ data, onOpenParty, onNavigate }: NotificationsProps) {
  const lowStock = useMemo(
    () =>
      data.stock
        .map((s) => ({
          ...s,
          isLow: s.reorderLevel != null && s.quantityGaz <= (s.reorderLevel || 0),
          isOut: s.quantityGaz <= 0,
        }))
        .filter((s) => s.isLow || s.isOut)
        .sort((a, b) => a.quantityGaz - b.quantityGaz),
    [data.stock],
  );

  const debtors = useMemo(
    () =>
      data.parties
        .map((p) => ({ party: p, balance: partyBalance(p.id, data.transactions) }))
        .filter((x) => x.balance > 0)
        .sort((a, b) => b.balance - a.balance),
    [data.parties, data.transactions],
  );

  const sendReminder = (name: string, phone: string, balance: number) => {
    const msg = `Assalam o Alaikum ${name},\n\nAapke account ka balance: *${formatCurrency(balance, data.settings.currency)}* hai (OMITEK Embroidery).\n\nMeharbani farma kar payment clear kar dein. Jazak Allah.\n\n- ${data.settings.shopName}`;
    const url = `https://wa.me/${normalizePhone(phone)}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  };

  const totalOutstanding = debtors.reduce((s, d) => s + d.balance, 0);
  const lowStockValue = lowStock.reduce(
    (s, item) => s + (item.costPerGaz ?? 0) * item.quantityGaz,
    0,
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Bell className="h-6 w-6 text-emerald-600" /> Notifications
        </h2>
        <p className="text-muted-foreground text-sm mt-1">
          Low-stock alerts and customers with outstanding balances.
        </p>
      </div>

      {/* Low stock */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Package className="h-4 w-4 text-amber-600" /> Low Stock Alerts
            <Badge variant={lowStock.length > 0 ? "destructive" : "secondary"}>{lowStock.length}</Badge>
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={() => onNavigate("stock")}>
            Manage Stock
          </Button>
        </CardHeader>
        <CardContent className="pt-0 space-y-2">
          {lowStock.length === 0 ? (
            <div className="text-center text-muted-foreground py-6 text-sm">
              All stock items are above their reorder level. ✅
            </div>
          ) : (
            <>
              <div className="text-xs text-muted-foreground mb-2">
                Total value at risk: {formatCurrency(lowStockValue, data.settings.currency)}
              </div>
              {lowStock.map((s) => (
                <div
                  key={s.id}
                  className="flex items-center justify-between p-3 rounded-md border bg-amber-50/50 dark:bg-amber-950/20"
                >
                  <div className="flex items-center gap-3">
                    <AlertTriangle className={`h-5 w-5 ${s.isOut ? "text-red-600" : "text-amber-600"}`} />
                    <div>
                      <div className="font-medium">{s.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {s.isOut ? "Out of stock!" : `${s.quantityGaz} Gaz left · reorder at ${s.reorderLevel}`}
                      </div>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => onNavigate("stock")}>
                    Restock
                  </Button>
                </div>
              ))}
            </>
          )}
        </CardContent>
      </Card>

      {/* Outstanding customers */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Users className="h-4 w-4 text-red-600" /> Outstanding Balances
            <Badge variant={debtors.length > 0 ? "destructive" : "secondary"}>{debtors.length}</Badge>
          </CardTitle>
          <div className="text-sm text-muted-foreground">
            Total: <span className="font-bold text-red-600">{formatCurrency(totalOutstanding, data.settings.currency)}</span>
          </div>
        </CardHeader>
        <CardContent className="pt-0 space-y-2">
          {debtors.length === 0 ? (
            <div className="text-center text-muted-foreground py-6 text-sm">
              No outstanding balances. All customers settled. 🎉
            </div>
          ) : (
            debtors.map((d) => (
              <div
                key={d.party.id}
                className="flex items-center justify-between p-3 rounded-md border bg-red-50/50 dark:bg-red-950/20"
              >
                <button
                  onClick={() => onOpenParty(d.party.id)}
                  className="flex items-center gap-3 text-left flex-1 min-w-0"
                >
                  <div className="rounded-full bg-red-100 dark:bg-red-900/40 p-2 text-red-700 dark:text-red-300">
                    <Users className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-medium truncate">{d.party.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {d.party.phone ? d.party.phone : "No phone"}
                    </div>
                  </div>
                  <Badge variant="destructive" className="ml-auto">
                    {formatCurrency(d.balance, data.settings.currency)}
                  </Badge>
                </button>
                {d.party.phone && (
                  <Button
                    size="sm"
                    className="ml-2 bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => sendReminder(d.party.name, d.party.phone, d.balance)}
                  >
                    <MessageCircle className="h-3 w-3 mr-1" /> Remind
                  </Button>
                )}
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}

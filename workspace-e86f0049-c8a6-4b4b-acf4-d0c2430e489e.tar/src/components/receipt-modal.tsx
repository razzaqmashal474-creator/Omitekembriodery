"use client";

import { useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer, MessageCircle } from "lucide-react";
import { AppData, Transaction, Party, PAYMENT_METHODS } from "@/lib/types";
import { formatCurrency, formatDateTime, normalizePhone } from "@/lib/format";
import { partyBalance } from "@/lib/store";

interface ReceiptModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transaction: Transaction | null;
  party: Party | null;
  data: AppData;
}

export default function ReceiptModal({
  open,
  onOpenChange,
  transaction,
  party,
  data,
}: ReceiptModalProps) {
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onOpenChange(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onOpenChange]);

  if (!transaction || !party) return null;

  const isSale = transaction.type === "sale";
  const isPayment = transaction.type === "payment";
  const isReturn = transaction.type === "sale_return";
  const balance = partyBalance(party.id, data.transactions);
  const methodLabel = transaction.paymentMethod
    ? PAYMENT_METHODS.find((m) => m.value === transaction.paymentMethod)?.label
    : null;

  const receiptText = `${data.settings.shopName}
Receipt: ${transaction.receiptNo}
Date: ${formatDateTime(transaction.date)}
Party: ${party.name}
${party.phone ? `Phone: ${party.phone}\n` : ""}${isSale ? "SALE" : isPayment ? "PAYMENT" : isReturn ? "SALE RETURN" : "TRANSACTION"}
${isSale && transaction.laceName ? `Lace: ${transaction.laceName}
Stitch: ${transaction.stitch}
Rate: ${transaction.rate}
One Gaz: ${formatCurrency(transaction.unitPrice || 0, data.settings.currency)}
Quantity: ${transaction.gazz} Gaz
` : ""}Amount: ${formatCurrency(transaction.amount, data.settings.currency)}
${methodLabel ? `Method: ${methodLabel}\n` : ""}${transaction.description ? `Details: ${transaction.description}\n` : ""}Balance: ${balance > 0 ? `Due ${formatCurrency(balance, data.settings.currency)}` : balance < 0 ? `Advance ${formatCurrency(Math.abs(balance), data.settings.currency)}` : "Settled"}

Thank you!`;

  const handlePrint = () => {
    const el = printRef.current;
    if (!el) return;
    const html = el.innerHTML;
    const win = window.open("", "_blank", "width=420,height=640");
    if (!win) {
      alert("Pop-up blocked. Please allow pop-ups to print the receipt.");
      return;
    }
    win.document.write(`
      <html>
        <head>
          <title>Receipt ${transaction.receiptNo}</title>
          <meta charset="utf-8" />
          <style>
            * { box-sizing: border-box; }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              margin: 0; padding: 16px; color: #111; background: #fff; width: 80mm;
            }
            .header { text-align: center; border-bottom: 2px dashed #888; padding-bottom: 8px; margin-bottom: 8px; }
            .shop-name { font-size: 18px; font-weight: 700; }
            .shop-meta { font-size: 11px; color: #555; margin-top: 2px; }
            .row { display: flex; justify-content: space-between; font-size: 12px; margin: 2px 0; }
            .label { color: #555; }
            .value { font-weight: 600; }
            .title { text-align: center; font-weight: 700; font-size: 14px; margin: 10px 0; padding: 4px; border: 1px dashed #888; }
            .sale { background: #ecfdf5; }
            .pay  { background: #fef3c7; }
            .ret  { background: #dbeafe; }
            .amount { text-align: center; font-size: 28px; font-weight: 800; margin: 10px 0; }
            .amount.sale { color: #047857; }
            .amount.pay  { color: #b45309; }
            .amount.ret  { color: #1d4ed8; }
            .lace-box { border: 1px solid #ddd; padding: 8px; margin-top: 8px; font-size: 12px; }
            .lace-row { display: flex; justify-content: space-between; margin: 2px 0; }
            .footer { margin-top: 12px; border-top: 2px dashed #888; padding-top: 8px; text-align: center; font-size: 11px; color: #555; }
            .balance { margin-top: 6px; font-weight: 700; text-align: center; }
          </style>
        </head>
        <body>${html}</body>
      </html>
    `);
    win.document.close();
    win.focus();
    setTimeout(() => {
      win.print();
      win.close();
    }, 250);
  };

  const handleWhatsApp = () => {
    if (!party.phone) {
      alert("This party has no mobile number. Please add one to share via WhatsApp.");
      return;
    }
    const url = `https://wa.me/${normalizePhone(party.phone)}?text=${encodeURIComponent(receiptText)}`;
    window.open(url, "_blank");
  };

  const titleBg = isSale ? "sale" : isPayment ? "pay" : isReturn ? "ret" : "";
  const amountColor = isSale ? "sale" : isPayment ? "pay" : isReturn ? "ret" : "";
  const titleText = isSale ? "SALE RECEIPT" : isPayment ? "PAYMENT RECEIPT" : isReturn ? "SALE RETURN RECEIPT" : "TRANSACTION";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Receipt Preview</DialogTitle>
          <DialogDescription>
            Receipt No. {transaction.receiptNo} · Print, save as PDF, or share on WhatsApp.
          </DialogDescription>
        </DialogHeader>

        <div
          ref={printRef}
          className="bg-white text-black p-4 rounded-md border font-sans text-sm"
        >
          <div className="header" style={{ textAlign: "center", borderBottom: "2px dashed #888", paddingBottom: "8px", marginBottom: "8px" }}>
            <div className="shop-name" style={{ fontSize: "18px", fontWeight: 700 }}>
              {data.settings.shopName}
            </div>
            {data.settings.shopPhone && (
              <div className="shop-meta" style={{ fontSize: "11px", color: "#555", marginTop: "2px" }}>
                {data.settings.shopPhone}
              </div>
            )}
            {data.settings.shopAddress && (
              <div className="shop-meta" style={{ fontSize: "11px", color: "#555" }}>
                {data.settings.shopAddress}
              </div>
            )}
          </div>

          <div className="row" style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", margin: "2px 0" }}>
            <span className="label" style={{ color: "#555" }}>Receipt No:</span>
            <span className="value" style={{ fontWeight: 600 }}>{transaction.receiptNo}</span>
          </div>
          <div className="row" style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", margin: "2px 0" }}>
            <span className="label" style={{ color: "#555" }}>Date & Time:</span>
            <span className="value" style={{ fontWeight: 600 }}>{formatDateTime(transaction.date)}</span>
          </div>
          <div className="row" style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", margin: "2px 0" }}>
            <span className="label" style={{ color: "#555" }}>Party:</span>
            <span className="value" style={{ fontWeight: 600 }}>{party.name}</span>
          </div>
          {party.phone && (
            <div className="row" style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", margin: "2px 0" }}>
              <span className="label" style={{ color: "#555" }}>Mobile:</span>
              <span className="value" style={{ fontWeight: 600 }}>{party.phone}</span>
            </div>
          )}

          <div
            className={`title ${titleBg}`}
            style={{
              textAlign: "center",
              fontWeight: 700,
              fontSize: "14px",
              margin: "10px 0",
              padding: "4px",
              border: "1px dashed #888",
              background: isSale ? "#ecfdf5" : isPayment ? "#fef3c7" : isReturn ? "#dbeafe" : "#f3f4f6",
            }}
          >
            {titleText}
          </div>

          {isSale && transaction.laceName && (
            <div className="lace-box" style={{ border: "1px solid #ddd", padding: "8px", marginTop: "8px", fontSize: "12px" }}>
              <div className="lace-row" style={{ display: "flex", justifyContent: "space-between", margin: "2px 0" }}>
                <span>Lace:</span><span>{transaction.laceName}</span>
              </div>
              <div className="lace-row" style={{ display: "flex", justifyContent: "space-between", margin: "2px 0" }}>
                <span>Stitch:</span><span>{transaction.stitch}</span>
              </div>
              <div className="lace-row" style={{ display: "flex", justifyContent: "space-between", margin: "2px 0" }}>
                <span>Rate:</span><span>{transaction.rate}</span>
              </div>
              <div className="lace-row" style={{ display: "flex", justifyContent: "space-between", margin: "2px 0" }}>
                <span>One Gaz price:</span>
                <span>{formatCurrency(transaction.unitPrice || 0, data.settings.currency)}</span>
              </div>
              <div className="lace-row" style={{ display: "flex", justifyContent: "space-between", margin: "2px 0" }}>
                <span>Quantity (Gaz):</span><span>{transaction.gazz}</span>
              </div>
            </div>
          )}

          <div
            className={`amount ${amountColor}`}
            style={{
              textAlign: "center",
              fontSize: "28px",
              fontWeight: 800,
              margin: "10px 0",
              color: isSale ? "#047857" : isPayment ? "#b45309" : isReturn ? "#1d4ed8" : "#111",
            }}
          >
            {formatCurrency(transaction.amount, data.settings.currency)}
          </div>

          {methodLabel && (
            <div className="row" style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", margin: "2px 0" }}>
              <span className="label" style={{ color: "#555" }}>Payment Method:</span>
              <span className="value" style={{ fontWeight: 600 }}>{methodLabel}</span>
            </div>
          )}

          {transaction.description && (
            <div className="row" style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", margin: "2px 0" }}>
              <span className="label" style={{ color: "#555" }}>Details:</span>
              <span className="value" style={{ fontWeight: 600 }}>{transaction.description}</span>
            </div>
          )}

          <div className="balance" style={{ marginTop: "6px", fontWeight: 700, textAlign: "center" }}>
            {balance > 0
              ? `Balance due: ${formatCurrency(balance, data.settings.currency)}`
              : balance < 0
                ? `Advance: ${formatCurrency(Math.abs(balance), data.settings.currency)}`
                : "Account settled"}
          </div>

          <div className="footer" style={{ marginTop: "12px", borderTop: "2px dashed #888", paddingTop: "8px", textAlign: "center", fontSize: "11px", color: "#555" }}>
            Thank you for your business!
          </div>
        </div>

        <div className="flex gap-2 justify-end flex-wrap">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          <Button
            onClick={handleWhatsApp}
            className="bg-green-600 hover:bg-green-700 text-white"
            disabled={!party.phone}
          >
            <MessageCircle className="mr-2 h-4 w-4" /> WhatsApp
          </Button>
          <Button onClick={handlePrint} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            <Printer className="mr-2 h-4 w-4" /> Print / PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

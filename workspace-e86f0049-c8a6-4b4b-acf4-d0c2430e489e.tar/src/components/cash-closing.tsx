"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Lock, FileDown, Calendar, TrendingUp } from "lucide-react";
import { AppData } from "@/lib/types";
import { formatCurrency, formatDate, isSameDay, dayKey } from "@/lib/format";
import { exportCashClosingPDF } from "@/lib/export";

interface CashClosingProps {
  data: AppData;
  onSave: (input: { date: string; openingCash: number; salesCash: number; paymentsCash: number; expensesCash: number; purchasesCash: number; expectedCash: number; countedCash: number; difference: number; note?: string }) => void;
}

export default function CashClosing({ data, onSave }: CashClosingProps) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [openingCash, setOpeningCash] = useState("0");
  const [countedCash, setCountedCash] = useState("");
  const [note, setNote] = useState("");

  const day = useMemo(() => {
    const target = new Date(date);
    const targetISO = target.toISOString();
    const tx = data.transactions.filter((t) => isSameDay(t.date, targetISO));
    const exp = data.expenses.filter((e) => isSameDay(e.date, targetISO));
    const pur = data.purchases.filter((p) => isSameDay(p.date, targetISO));
    const sales = tx.filter((t) => t.type === "sale").reduce((s, t) => s + t.amount, 0);
    const returns = tx.filter((t) => t.type === "sale_return").reduce((s, t) => s + t.amount, 0);
    const payments = tx.filter((t) => t.type === "payment").reduce((s, t) => s + t.amount, 0);
    const expenses = exp.reduce((s, e) => s + e.amount, 0);
    const purchases = pur.reduce((s, p) => s + p.amountPaid, 0);
    const opening = Number(openingCash) || 0;
    const expected = opening + (sales - returns) + payments - expenses - purchases;
    const counted = Number(countedCash) || 0;
    const diff = counted - expected;
    return { sales, returns, payments, expenses, purchases, opening, expected, counted, diff, tx, exp, pur };
  }, [data, date, openingCash, countedCash]);

  const existing = useMemo(
    () => data.cashClosings.find((c) => dayKey(c.date) === dayKey(new Date(date).toISOString())),
    [data.cashClosings, date],
  );

  const handleSave = () => {
    onSave({
      date: new Date(date).toISOString(),
      openingCash: day.opening,
      salesCash: day.sales - day.returns,
      paymentsCash: day.payments,
      expensesCash: day.expenses,
      purchasesCash: day.purchases,
      expectedCash: day.expected,
      countedCash: day.counted,
      difference: day.diff,
      note: note.trim() || undefined,
    });
    alert("Cash closing saved!");
  };

  const handlePDF = () => {
    exportCashClosingPDF(
      new Date(date).toISOString(),
      day.opening, day.sales - day.returns, day.payments, day.expenses, day.purchases,
      day.expected, day.counted, day.diff, data,
    );
  };

  const sortedClosings = useMemo(
    () => [...data.cashClosings].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
    [data.cashClosings],
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Lock className="h-6 w-6 text-emerald-600" /> Daily Cash Closing
        </h2>
        <p className="text-muted-foreground text-sm mt-1">
          End-of-day report: opening cash, today&apos;s sales, payments, expenses, purchases, expected & counted cash.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Calendar className="h-4 w-4" /> Closing for</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3 items-end flex-wrap">
            <div className="space-y-1">
              <Label htmlFor="cdate">Date</Label>
              <Input id="cdate" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="copen">Opening Cash</Label>
              <Input id="copen" inputMode="decimal" value={openingCash} onChange={(e) => setOpeningCash(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="ccounted">Counted Cash (in drawer)</Label>
              <Input id="ccounted" inputMode="decimal" value={countedCash} onChange={(e) => setCountedCash(e.target.value)} placeholder="0" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Computed Breakdown</CardTitle>
          <CardDescription>Auto-calculated from today&apos;s transactions.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Row label="Opening Cash" value={day.opening} currency={data.settings.currency} />
          <Row label="Cash Sales" value={day.sales - day.returns} currency={data.settings.currency} />
          <Row label="Payments Received" value={day.payments} currency={data.settings.currency} />
          <Row label="(-) Expenses" value={-day.expenses} currency={data.settings.currency} />
          <Row label="(-) Purchases Paid" value={-day.purchases} currency={data.settings.currency} />
          <div className="border-t pt-2 mt-2">
            <Row label="Expected Cash" value={day.expected} currency={data.settings.currency} bold />
          </div>
          <Row label="Counted Cash" value={day.counted} currency={data.settings.currency} bold />
          <div className="flex justify-between items-center p-2 rounded-md bg-muted/40">
            <span className="text-sm font-medium">Difference</span>
            <Badge variant={Math.abs(day.diff) < 1 ? "secondary" : "destructive"}>
              {formatCurrency(day.diff, data.settings.currency)}
            </Badge>
          </div>
          <div className="space-y-1 pt-2">
            <Label>Note</Label>
            <Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional: explanation for any difference" />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-2 flex-wrap">
        <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <Lock className="mr-2 h-4 w-4" /> {existing ? "Update Closing" : "Save Closing"}
        </Button>
        <Button variant="outline" onClick={handlePDF}>
          <FileDown className="mr-2 h-4 w-4" /> Export PDF
        </Button>
      </div>

      {sortedClosings.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4" /> Previous Closings
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-card">
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Opening</TableHead>
                    <TableHead className="text-right">Sales</TableHead>
                    <TableHead className="text-right">Payments</TableHead>
                    <TableHead className="text-right">Expenses</TableHead>
                    <TableHead className="text-right">Expected</TableHead>
                    <TableHead className="text-right">Counted</TableHead>
                    <TableHead className="text-right">Diff</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedClosings.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="whitespace-nowrap">{formatDate(c.date)}</TableCell>
                      <TableCell className="text-right font-mono text-xs">{formatCurrency(c.openingCash, data.settings.currency)}</TableCell>
                      <TableCell className="text-right font-mono text-xs">{formatCurrency(c.salesCash, data.settings.currency)}</TableCell>
                      <TableCell className="text-right font-mono text-xs">{formatCurrency(c.paymentsCash, data.settings.currency)}</TableCell>
                      <TableCell className="text-right font-mono text-xs">{formatCurrency(c.expensesCash, data.settings.currency)}</TableCell>
                      <TableCell className="text-right font-mono text-xs font-semibold">{formatCurrency(c.expectedCash, data.settings.currency)}</TableCell>
                      <TableCell className="text-right font-mono text-xs">{formatCurrency(c.countedCash, data.settings.currency)}</TableCell>
                      <TableCell className={`text-right font-mono text-xs ${Math.abs(c.difference) > 1 ? "text-red-600 font-bold" : "text-emerald-600"}`}>
                        {formatCurrency(c.difference, data.settings.currency)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Row({ label, value, currency, bold }: { label: string; value: number; currency: string; bold?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className={`text-sm ${bold ? "font-semibold" : ""}`}>{label}</span>
      <span className={`font-mono ${bold ? "font-bold" : ""}`}>{formatCurrency(value, currency)}</span>
    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, UserPlus, Phone, MapPin, ChevronRight, Truck } from "lucide-react";
import { Supplier, Purchase } from "@/lib/types";
import { supplierBalance, supplierPurchaseTotal, supplierPaidTotal } from "@/lib/store";
import { formatCurrency } from "@/lib/format";

interface SuppliersProps {
  suppliers: Supplier[];
  purchases: Purchase[];
  currency: string;
  onAdd: (input: { name: string; phone: string; address?: string; notes?: string; openingBalance?: number }) => Supplier;
  onOpen: (id: string) => void;
}

export default function Suppliers({ suppliers, purchases, currency, onAdd, onOpen }: SuppliersProps) {
  const [search, setSearch] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [openingBalance, setOpeningBalance] = useState("");
  const [showForm, setShowForm] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return suppliers;
    return suppliers.filter(
      (s) => s.name.toLowerCase().includes(q) || s.phone.toLowerCase().includes(q),
    );
  }, [suppliers, search]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAdd({
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim() || undefined,
      notes: notes.trim() || undefined,
      openingBalance: openingBalance ? Number(openingBalance) : undefined,
    });
    setName("");
    setPhone("");
    setAddress("");
    setNotes("");
    setOpeningBalance("");
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Truck className="h-6 w-6 text-emerald-600" /> Suppliers
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Manage lace suppliers and track purchases/payments with each.
          </p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <UserPlus className="mr-2 h-4 w-4" />
          {showForm ? "Close" : "Add Supplier"}
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>New Supplier</CardTitle>
            <CardDescription>Add a lace supplier. Opening balance = money you already owe them.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdd} className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="sname">Supplier Name *</Label>
                <Input id="sname" required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Kareem Lace Wala" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sphone">Mobile Number</Label>
                <Input id="sphone" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="03xx-xxxxxxx" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sopen">Opening Balance (Rs.) — already owed</Label>
                <Input id="sopen" inputMode="decimal" value={openingBalance} onChange={(e) => setOpeningBalance(e.target.value)} placeholder="0" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="saddr">Address</Label>
                <Input id="saddr" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Shop / market" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="snotes">Notes</Label>
                <Textarea id="snotes" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Optional notes" />
              </div>
              <div className="md:col-span-2 flex gap-2">
                <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">Save Supplier</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search suppliers..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            {suppliers.length === 0 ? "No suppliers yet." : "No match."}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {filtered.map((s) => {
            const bal = supplierBalance(s.id, purchases) + (s.openingBalance || 0);
            const purchasesTotal = supplierPurchaseTotal(s.id, purchases);
            return (
              <button key={s.id} onClick={() => onOpen(s.id)} className="text-left">
                <Card className="hover:border-emerald-400 hover:shadow-md transition cursor-pointer h-full">
                  <CardContent className="p-4 flex items-center gap-4">
                    <Avatar className="h-12 w-12 bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-200">
                      <AvatarFallback>{s.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold truncate">{s.name}</span>
                        {bal > 0 ? (
                          <Badge variant="destructive" className="text-xs">You owe {formatCurrency(bal, currency)}</Badge>
                        ) : bal < 0 ? (
                          <Badge className="bg-emerald-600 text-white text-xs">Advance {formatCurrency(Math.abs(bal), currency)}</Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">Settled</Badge>
                        )}
                      </div>
                      {s.phone && (
                        <div className="text-sm text-muted-foreground flex items-center gap-1 mt-0.5">
                          <Phone className="h-3 w-3" /> {s.phone}
                        </div>
                      )}
                      {s.address && (
                        <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5 truncate">
                          <MapPin className="h-3 w-3" /> {s.address}
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground mt-1">Purchases: {formatCurrency(purchasesTotal, currency)}</div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </CardContent>
                </Card>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

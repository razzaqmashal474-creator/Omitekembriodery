import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { PWARegister } from "@/components/pwa";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://omitek-embroidery.local"),
  title: {
    default: "OMITEK Embroidery — Lace Business Manager",
    template: "%s · OMITEK",
  },
  description:
    "Complete lace / embroidery business management system: price calculator, customer & supplier ledgers, stock with barcodes, sale returns, payments, P&L, daily cash closing, WhatsApp receipts, Excel/PDF export, staff login with permissions. All data stored locally on this computer.",
  applicationName: "OMITEK Embroidery",
  keywords: [
    "OMITEK",
    "embroidery",
    "lace price calculator",
    "lace business",
    "customer ledger",
    "khata",
    "udhaar",
    "party account",
    "supplier management",
    "stock barcode",
    "profit and loss",
    "cash closing",
    "whatsapp receipt",
  ],
  authors: [{ name: "OMITEK Embroidery" }],
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
    shortcut: ["/icon-192.png"],
  },
  appleWebApp: {
    capable: true,
    title: "OMITEK",
    statusBarStyle: "default",
    startupImage: ["/icon-512.png"],
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    title: "OMITEK Embroidery — Lace Business Manager",
    description: "Calculator + customer/supplier ledgers + stock + P&L + cash closing + WhatsApp receipts — all on this computer.",
    type: "website",
    images: [{ url: "/icon-512.png", width: 512, height: 512 }],
  },
  twitter: {
    card: "summary",
    title: "OMITEK Embroidery",
    description: "Lace Business Manager",
    images: ["/icon-512.png"],
  },
};

export const viewport: Viewport = {
  themeColor: "#10b981",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Extra mobile web app meta tags for older iOS */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="OMITEK" />
        <meta name="application-name" content="OMITEK Embroidery" />
        <meta name="msapplication-TileColor" content="#10b981" />
        <meta name="msapplication-tap-highlight" content="no" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <PWARegister />
        {children}
        <Toaster />
      </body>
    </html>
  );
}

"use client";

import { useState, useEffect, useMemo } from "react";
import { useStore } from "@/lib/store";
import { useAuth, canAccess } from "@/lib/auth";
import { StaffUser } from "@/lib/types";
import Login from "@/components/login";
import Dashboard from "@/components/dashboard";
import Calculator from "@/components/calculator";
import Parties from "@/components/parties";
import PartyDetail from "@/components/party-detail";
import Stock from "@/components/stock";
import Expenses from "@/components/expenses";
import Reports from "@/components/reports";
import Backup from "@/components/backup";
import Suppliers from "@/components/suppliers";
import SupplierDetail from "@/components/supplier-detail";
import CashClosing from "@/components/cash-closing";
import Notifications from "@/components/notifications";
import Staff from "@/components/staff";
import {
  LayoutDashboard, Calculator as CalcIcon, Users, Package, Receipt, TrendingDown, BarChart3, DatabaseBackup,
  Scissors, Menu, X, Truck, Lock, Bell, LogOut, Download,
} from "lucide-react";
import { usePWAInstallPrompt } from "@/components/pwa";

type Tab =
  | "dashboard" | "calculator" | "parties" | "suppliers" | "stock"
  | "expenses" | "cash-closing" | "reports" | "notifications" | "staff" | "backup";

const NAV: { id: Tab; label: string; icon: typeof LayoutDashboard; feature?: "reports" | "backup" | "stock" | "parties"; mobile?: boolean }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, mobile: true },
  { id: "calculator", label: "Calculator", icon: CalcIcon, mobile: true },
  { id: "parties", label: "Parties", icon: Users, feature: "parties", mobile: true },
  { id: "suppliers", label: "Suppliers", icon: Truck },
  { id: "stock", label: "Stock", icon: Package, feature: "stock", mobile: true },
  { id: "expenses", label: "Expenses", icon: TrendingDown },
  { id: "cash-closing", label: "Cash Closing", icon: Lock },
  { id: "reports", label: "Reports", icon: BarChart3, feature: "reports", mobile: true },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "staff", label: "Staff", icon: Users },
  { id: "backup", label: "Backup & Settings", icon: DatabaseBackup, feature: "backup" },
];

export default function Home() {
  const store = useStore();
  const { data } = store;
  const { userId, login, logout } = useAuth();
  const { canInstall, prompt: promptInstall } = usePWAInstallPrompt();
  const [tab, setTab] = useState<Tab>("dashboard");
  const [openPartyId, setOpenPartyId] = useState<string | null>(null);
  const [openSupplierId, setOpenSupplierId] = useState<string | null>(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const currentUser = useMemo(
    () => data.staff.find((s) => s.id === userId) || null,
    [data.staff, userId],
  );

  // First-time admin creation: expose a global function for the Login component.
  useEffect(() => {
    const w = window as unknown as { __omitekCreateAdmin?: (name: string, uname: string, pin: string) => void };
    w.__omitekCreateAdmin = (name: string, uname: string, pin: string) => {
      const user = store.addStaff({
        name,
        username: uname.toLowerCase(),
        pin,
        role: "admin",
        active: true,
      });
      login(user.id);
    };
    return () => { delete w.__omitekCreateAdmin; };
  }, [store, login]);

  // If no staff exists yet, show only the login screen (which becomes a create-admin screen).
  if (data.staff.length === 0 || !currentUser) {
    return <Login data={data} onLogin={login} />;
  }

  const openParty = (id: string) => {
    setOpenPartyId(id);
    setOpenSupplierId(null);
    setTab("parties");
  };

  const openSupplier = (id: string) => {
    setOpenSupplierId(id);
    setOpenPartyId(null);
    setTab("suppliers");
  };

  const handleNav = (id: string) => {
    // Permission check
    const navItem = NAV.find((n) => n.id === id);
    if (navItem?.feature && !canAccess(currentUser, navItem.feature, data.settings)) {
      alert("You do not have permission to access this section. Ask the admin.");
      return;
    }
    setTab(id as Tab);
    setOpenPartyId(null);
    setOpenSupplierId(null);
    setMobileNavOpen(false);
  };

  const party = openPartyId ? data.parties.find((p) => p.id === openPartyId) : undefined;
  const supplier = openSupplierId ? data.suppliers.find((s) => s.id === openSupplierId) : undefined;

  const filteredNav = NAV.filter((n) => !n.feature || canAccess(currentUser, n.feature, data.settings));
  const mobileNav = filteredNav.filter((n) => n.mobile);

  const lowStockCount = data.stock.filter(
    (s) => s.reorderLevel != null && s.quantityGaz <= (s.reorderLevel || 0),
  ).length;
  const debtorCount = data.parties.filter((p) => {
    const bal = data.transactions
      .filter((t) => t.partyId === p.id)
      .reduce((sum, t) => sum + (t.type === "sale" || t.type === "opening" ? t.amount : -t.amount), 0);
    return bal > 0;
  }).length;
  const alertCount = lowStockCount + debtorCount;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <button
              className="md:hidden p-2 -ml-2 rounded-md hover:bg-muted"
              onClick={() => setMobileNavOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              {mobileNavOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-sm">
                <Scissors className="h-5 w-5" />
              </div>
              <div>
                <div className="font-bold text-base leading-tight">{data.settings.shopName}</div>
                <div className="text-xs text-muted-foreground leading-tight">Lace Business Manager</div>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {canInstall && (
              <button
                onClick={promptInstall}
                className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-md bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-700 transition"
                title="Install OMITEK as an app on this device"
              >
                <Download className="h-3 w-3" /> Install App
              </button>
            )}
            {alertCount > 0 && (
              <button
                onClick={() => handleNav("notifications")}
                className="relative p-2 rounded-md hover:bg-muted"
                title={`${alertCount} alerts`}
              >
                <Bell className="h-4 w-4" />
                <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] rounded-full h-4 w-4 flex items-center justify-center">
                  {alertCount}
                </span>
              </button>
            )}
            <div className="hidden sm:flex items-center gap-2 text-sm">
              <div className="text-right">
                <div className="font-medium text-xs">{currentUser.name}</div>
                <div className="text-xs text-muted-foreground capitalize">{currentUser.role}</div>
              </div>
              <button
                onClick={logout}
                className="p-2 rounded-md hover:bg-muted"
                title="Sign out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 w-full">
        {/* Sidebar (desktop) */}
        <aside className="hidden md:flex md:flex-col w-60 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 sticky top-[57px] h-[calc(100vh-57px)]">
          <nav className="flex flex-col gap-1 p-3 flex-1 overflow-y-auto">
            {filteredNav.map((item) => {
              const Icon = item.icon;
              const active = tab === item.id && !openPartyId && !openSupplierId;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition ${
                    active
                      ? "bg-emerald-600 text-white shadow-sm"
                      : "text-slate-700 dark:text-slate-300 hover:bg-muted"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                  {item.id === "notifications" && alertCount > 0 && (
                    <span className="ml-auto bg-red-600 text-white text-[10px] rounded-full h-4 min-w-4 px-1 flex items-center justify-center">
                      {alertCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
          <div className="p-3 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={logout}
              className="md:hidden w-full flex items-center justify-center gap-2 px-3 py-2 rounded-md text-sm bg-muted hover:bg-muted/80"
            >
              <LogOut className="h-4 w-4" /> Sign Out
            </button>
            <div className="hidden md:block text-xs text-muted-foreground">
              Signed in as <span className="font-medium">{currentUser.name}</span>
              <br />Data saved on this device only.
            </div>
          </div>
        </aside>

        {/* Mobile nav drawer */}
        {mobileNavOpen && (
          <div className="md:hidden fixed inset-0 z-40 bg-black/40" onClick={() => setMobileNavOpen(false)}>
            <div
              className="absolute left-0 top-0 bottom-0 w-64 bg-white dark:bg-slate-900 p-3 overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-4 px-2">
                <span className="font-bold">Menu</span>
                <button onClick={() => setMobileNavOpen(false)}><X className="h-5 w-5" /></button>
              </div>
              <nav className="flex flex-col gap-1">
                {filteredNav.map((item) => {
                  const Icon = item.icon;
                  const active = tab === item.id && !openPartyId && !openSupplierId;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNav(item.id)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium ${
                        active ? "bg-emerald-600 text-white" : "text-slate-700 dark:text-slate-300 hover:bg-muted"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                      {item.id === "notifications" && alertCount > 0 && (
                        <span className="ml-auto bg-red-600 text-white text-[10px] rounded-full h-4 min-w-4 px-1 flex items-center justify-center">
                          {alertCount}
                        </span>
                      )}
                    </button>
                  );
                })}
                <button
                  onClick={logout}
                  className="mt-2 flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"
                >
                  <LogOut className="h-4 w-4" /> Sign Out
                </button>
              </nav>
            </div>
          </div>
        )}

        {/* Main content */}
        <main className="flex-1 min-w-0 p-4 md:p-6 max-w-5xl mx-auto w-full pb-24 md:pb-6">
          {tab === "dashboard" && (
            <Dashboard data={data} onNavigate={handleNav} onOpenParty={openParty} />
          )}
          {tab === "calculator" && <Calculator currency={data.settings.currency} />}
          {tab === "parties" && !party && (
            <Parties
              parties={data.parties}
              transactions={data.transactions}
              currency={data.settings.currency}
              onAdd={store.addParty}
              onOpen={openParty}
            />
          )}
          {tab === "parties" && party && (
            <PartyDetail
              party={party}
              data={data}
              onBack={() => setOpenPartyId(null)}
              onAddTransaction={store.addTransaction}
              onDeleteTransaction={store.deleteTransaction}
              onUpdateStock={store.updateStock}
            />
          )}
          {tab === "suppliers" && !supplier && (
            <Suppliers
              suppliers={data.suppliers}
              purchases={data.purchases}
              currency={data.settings.currency}
              onAdd={store.addSupplier}
              onOpen={openSupplier}
            />
          )}
          {tab === "suppliers" && supplier && (
            <SupplierDetail
              supplier={supplier}
              data={data}
              onBack={() => setOpenSupplierId(null)}
              onAddPurchase={store.addPurchase}
              onDeletePurchase={store.deletePurchase}
              onUpdatePurchase={store.updatePurchase}
            />
          )}
          {tab === "stock" && (
            <Stock
              stock={data.stock}
              adjustments={data.stockAdjustments}
              currency={data.settings.currency}
              onAdd={store.addStock}
              onUpdate={store.updateStock}
              onDelete={store.deleteStock}
              onAdjust={store.addStockAdjustment}
              onLookupBarcode={(code) => {
                const item = data.stock.find((s) => s.barcode === code);
                if (item) {
                  alert(`Found: ${item.name}\nIn stock: ${item.quantityGaz} Gaz\nOne Gaz: Rs. ${(item.stitch * item.rate / 1000).toFixed(2)}`);
                } else {
                  alert(`No lace with barcode "${code}" found.`);
                }
              }}
            />
          )}
          {tab === "expenses" && (
            <Expenses
              expenses={data.expenses}
              currency={data.settings.currency}
              onAdd={store.addExpense}
              onDelete={store.deleteExpense}
            />
          )}
          {tab === "cash-closing" && (
            <CashClosing data={data} onSave={store.saveCashClosing} />
          )}
          {tab === "reports" && <Reports data={data} />}
          {tab === "notifications" && (
            <Notifications data={data} onOpenParty={openParty} onNavigate={handleNav} />
          )}
          {tab === "staff" && (
            <Staff
              data={data}
              currentUser={currentUser}
              onAdd={store.addStaff}
              onUpdate={store.updateStaff}
              onDelete={store.deleteStaff}
              onUpdateSettings={store.updateSettings}
            />
          )}
          {tab === "backup" && (
            <Backup
              data={data}
              onUpdateSettings={store.updateSettings}
              onReplaceAll={store.replaceAll}
              onResetAll={store.resetAll}
            />
          )}
        </main>
      </div>

      {/* Bottom nav (mobile) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 grid grid-cols-5">
        {mobileNav.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id && !(item.id === "parties" && openPartyId) && !(item.id === "suppliers" && openSupplierId);
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`flex flex-col items-center justify-center py-2 text-[10px] gap-0.5 relative ${
                active ? "text-emerald-600" : "text-muted-foreground"
              }`}
            >
              <Icon className="h-5 w-5" />
              {item.label.split(" ")[0]}
              {item.id === "notifications" && alertCount > 0 && (
                <span className="absolute top-1 right-1/4 bg-red-600 text-white text-[8px] rounded-full h-3 min-w-3 px-1 flex items-center justify-center">
                  {alertCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}

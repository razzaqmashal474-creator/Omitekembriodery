"use client";

import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { AppData, Transaction, Party, Expense, Purchase } from "./types";
import { formatCurrency, formatDateTime, formatDate } from "./format";
import { partyBalance } from "./store";

// ---- Excel export ----

export function exportDataToExcel(data: AppData) {
  const wb = XLSX.utils.book_new();

  // Summary sheet
  const totalSales = data.transactions.filter((t) => t.type === "sale").reduce((s, t) => s + t.amount, 0);
  const totalReceived = data.transactions.filter((t) => t.type === "payment").reduce((s, t) => s + t.amount, 0);
  const totalReturns = data.transactions.filter((t) => t.type === "sale_return").reduce((s, t) => s + t.amount, 0);
  const totalExpenses = data.expenses.reduce((s, e) => s + e.amount, 0);
  const totalPurchases = data.purchases.reduce((s, p) => s + p.totalAmount, 0);
  const outstanding = data.parties.reduce((s, p) => s + Math.max(0, partyBalance(p.id, data.transactions)), 0);

  const summary = [
    ["OMITEK Embroidery — Business Summary"],
    ["Generated", formatDateTime(new Date().toISOString())],
    [],
    ["Metric", "Value"],
    ["Total Customers", data.parties.length],
    ["Total Suppliers", data.suppliers.length],
    ["Total Sales", totalSales],
    ["Total Received", totalReceived],
    ["Sale Returns", totalReturns],
    ["Total Expenses", totalExpenses],
    ["Total Purchases", totalPurchases],
    ["Outstanding Balance", outstanding],
    ["Stock Items", data.stock.length],
  ];
  const wsSummary = XLSX.utils.aoa_to_sheet(summary);
  XLSX.utils.book_append_sheet(wb, wsSummary, "Summary");

  // Parties sheet
  const partiesRows: (string | number)[][] = [["Name", "Phone", "Address", "Opening Bal", "Total Sales", "Total Paid", "Returns", "Current Bal"]];
  data.parties.forEach((p) => {
    const tx = data.transactions.filter((t) => t.partyId === p.id);
    const sales = tx.filter((t) => t.type === "sale").reduce((s, t) => s + t.amount, 0);
    const paid = tx.filter((t) => t.type === "payment").reduce((s, t) => s + t.amount, 0);
    const ret = tx.filter((t) => t.type === "sale_return").reduce((s, t) => s + t.amount, 0);
    partiesRows.push([p.name, p.phone, p.address || "", p.openingBalance || 0, sales, paid, ret, partyBalance(p.id, data.transactions)]);
  });
  const wsParties = XLSX.utils.aoa_to_sheet(partiesRows);
  XLSX.utils.book_append_sheet(wb, wsParties, "Parties");

  // Transactions sheet
  const txRows: (string | number)[][] = [["Receipt No", "Date", "Party", "Type", "Description", "Amount", "Payment Method", "Lace", "Gaz"]];
  data.transactions
    .slice()
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .forEach((t) => {
      const p = data.parties.find((x) => x.id === t.partyId);
      txRows.push([
        t.receiptNo,
        formatDateTime(t.date),
        p?.name || "",
        t.type,
        t.description,
        t.amount,
        t.paymentMethod || "",
        t.laceName || "",
        t.gazz || 0,
      ]);
    });
  const wsTx = XLSX.utils.aoa_to_sheet(txRows);
  XLSX.utils.book_append_sheet(wb, wsTx, "Transactions");

  // Stock sheet
  const stockRows: (string | number)[][] = [["Name", "Color", "Stitch", "Rate", "Cost/Gaz", "Quantity (Gaz)", "Stock Value", "Reorder Level", "Barcode"]];
  data.stock.forEach((s) => {
    const cost = s.costPerGaz ?? (s.stitch * s.rate) / 1000;
    stockRows.push([
      s.name,
      s.color || "",
      s.stitch,
      s.rate,
      cost,
      s.quantityGaz,
      cost * s.quantityGaz,
      s.reorderLevel || 0,
      s.barcode || "",
    ]);
  });
  const wsStock = XLSX.utils.aoa_to_sheet(stockRows);
  XLSX.utils.book_append_sheet(wb, wsStock, "Stock");

  // Expenses sheet
  const expRows: (string | number)[][] = [["Date", "Description", "Category", "Amount"]];
  data.expenses.forEach((e) => {
    expRows.push([formatDate(e.date), e.description, e.category, e.amount]);
  });
  const wsExp = XLSX.utils.aoa_to_sheet(expRows);
  XLSX.utils.book_append_sheet(wb, wsExp, "Expenses");

  // Purchases sheet
  const poRows: (string | number)[][] = [["Purchase No", "Date", "Supplier", "Lace", "Stitch", "Rate", "Gaz", "Total", "Paid", "Balance"]];
  data.purchases.forEach((p) => {
    const sup = data.suppliers.find((s) => s.id === p.supplierId);
    poRows.push([
      p.purchaseNo,
      formatDate(p.date),
      sup?.name || "",
      p.laceName,
      p.stitch,
      p.rate,
      p.gazz,
      p.totalAmount,
      p.amountPaid,
      p.totalAmount - p.amountPaid,
    ]);
  });
  const wsPo = XLSX.utils.aoa_to_sheet(poRows);
  XLSX.utils.book_append_sheet(wb, wsPo, "Purchases");

  XLSX.writeFile(wb, `omitek-export-${new Date().toISOString().slice(0, 10)}.xlsx`);
}

// ---- PDF: Customer Ledger ----

export function exportPartyLedgerPDF(party: Party, transactions: Transaction[], data: AppData) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const margin = 40;
  let y = margin;

  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text(data.settings.shopName, margin, y);
  y += 18;

  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Party Ledger: ${party.name}`, margin, y); y += 12;
  if (party.phone) { doc.text(`Phone: ${party.phone}`, margin, y); y += 12; }
  if (party.address) { doc.text(`Address: ${party.address}`, margin, y); y += 12; }
  doc.text(`Generated: ${formatDateTime(new Date().toISOString())}`, margin, y); y += 18;

  const bal = partyBalance(party.id, transactions);
  doc.setFont("helvetica", "bold");
  doc.text(`Current Balance: ${formatCurrency(bal, data.settings.currency)}${bal > 0 ? " (you owe this customer nothing / customer owes)" : bal < 0 ? " (advance)" : " (settled)"}`, margin, y);
  y += 20;

  const sorted = transactions.slice().sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  let running = 0;
  const rows = sorted.map((t) => {
    if (t.type === "sale" || t.type === "opening") running += t.amount;
    else running -= t.amount;
    return [
      formatDateTime(t.date),
      t.type.replace("_", " "),
      t.description,
      t.type === "sale" || t.type === "opening" ? formatCurrency(t.amount, data.settings.currency) : "",
      t.type === "payment" || t.type === "sale_return" ? formatCurrency(t.amount, data.settings.currency) : "",
      formatCurrency(running, data.settings.currency),
    ];
  });

  autoTable(doc, {
    head: [["Date", "Type", "Details", "Sale", "Payment", "Balance"]],
    body: rows,
    startY: y,
    margin: { left: margin, right: margin },
    styles: { fontSize: 8, cellPadding: 4 },
    headStyles: { fillColor: [16, 122, 87] },
  });

  doc.save(`ledger-${party.name.replace(/\s+/g, "-")}.pdf`);
}

// ---- PDF: Daily Cash Closing ----

export function exportCashClosingPDF(
  date: string,
  opening: number,
  sales: number,
  payments: number,
  expenses: number,
  purchases: number,
  expected: number,
  counted: number,
  diff: number,
  data: AppData,
) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const margin = 40;
  let y = margin;

  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text(data.settings.shopName, margin, y); y += 22;
  doc.setFontSize(14);
  doc.text("Daily Cash Closing Report", margin, y); y += 18;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Date: ${formatDate(date)}`, margin, y); y += 14;
  doc.text(`Generated: ${formatDateTime(new Date().toISOString())}`, margin, y); y += 22;

  autoTable(doc, {
    head: [["Description", "Amount"]],
    body: [
      ["Opening Cash", formatCurrency(opening, data.settings.currency)],
      ["Cash Sales", formatCurrency(sales, data.settings.currency)],
      ["Payments Received", formatCurrency(payments, data.settings.currency)],
      ["Expenses Paid", formatCurrency(-expenses, data.settings.currency)],
      ["Purchases Paid", formatCurrency(-purchases, data.settings.currency)],
      ["Expected Cash", formatCurrency(expected, data.settings.currency)],
      ["Counted Cash", formatCurrency(counted, data.settings.currency)],
      ["Difference", formatCurrency(diff, data.settings.currency)],
    ],
    startY: y,
    margin: { left: margin, right: margin },
    styles: { fontSize: 10, cellPadding: 6 },
    headStyles: { fillColor: [16, 122, 87] },
  });

  doc.save(`cash-closing-${date.slice(0, 10)}.pdf`);
}

// ---- PDF: full P&L ----

export function exportProfitLossPDF(data: AppData, period: "today" | "month" | "all") {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const margin = 40;
  let y = margin;

  const now = new Date().toISOString();
  const inPeriod = (d: string) => {
    if (period === "all") return true;
    const dt = new Date(d);
    const n = new Date(now);
    if (period === "today") return dt.toDateString() === n.toDateString();
    return dt.getMonth() === n.getMonth() && dt.getFullYear() === n.getFullYear();
  };

  const sales = data.transactions.filter((t) => t.type === "sale" && inPeriod(t.date)).reduce((s, t) => s + t.amount, 0);
  const returns = data.transactions.filter((t) => t.type === "sale_return" && inPeriod(t.date)).reduce((s, t) => s + t.amount, 0);
  const expenses = data.expenses.filter((e) => inPeriod(e.date)).reduce((s, e) => s + e.amount, 0);
  const purchases = data.purchases.filter((p) => inPeriod(p.date)).reduce((s, p) => s + p.amountPaid, 0);

  // COGS: sum of (costPerGaz * gazz) for each sale that has a linked stock item
  let cogs = 0;
  data.transactions
    .filter((t) => t.type === "sale" && inPeriod(t.date) && t.laceName)
    .forEach((t) => {
      const stockItem = data.stock.find((s) => s.name === t.laceName);
      const cost = stockItem?.costPerGaz ?? 0;
      cogs += cost * (t.gazz || 0);
    });

  const netSales = sales - returns;
  const grossProfit = netSales - cogs;
  const netProfit = grossProfit - expenses;

  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text(data.settings.shopName, margin, y); y += 22;
  doc.setFontSize(14);
  doc.text(`Profit & Loss Statement (${period})`, margin, y); y += 18;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Generated: ${formatDateTime(now)}`, margin, y); y += 22;

  autoTable(doc, {
    head: [["Item", "Amount"]],
    body: [
      ["Gross Sales", formatCurrency(sales, data.settings.currency)],
      ["(-) Sale Returns", formatCurrency(-returns, data.settings.currency)],
      ["Net Sales", formatCurrency(netSales, data.settings.currency)],
      ["(-) Cost of Goods Sold (COGS)", formatCurrency(-cogs, data.settings.currency)],
      ["Gross Profit", formatCurrency(grossProfit, data.settings.currency)],
      ["(-) Operating Expenses", formatCurrency(-expenses, data.settings.currency)],
      ["Net Profit", formatCurrency(netProfit, data.settings.currency)],
    ],
    startY: y,
    margin: { left: margin, right: margin },
    styles: { fontSize: 10, cellPadding: 6 },
    headStyles: { fillColor: [16, 122, 87] },
  });

  doc.save(`profit-loss-${period}-${new Date().toISOString().slice(0, 10)}.pdf`);
}

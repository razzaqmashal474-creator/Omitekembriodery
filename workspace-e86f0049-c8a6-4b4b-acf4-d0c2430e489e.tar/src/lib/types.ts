// Core data types for OMITEK Embroidery — Lace Business Management System.
// All data is stored locally in the browser via localStorage.

export type TransactionType = "sale" | "payment" | "sale_return" | "opening";

export type PaymentMethod =
  | "cash"
  | "bank"
  | "card"
  | "jazzcash"
  | "easypaisa"
  | "other";

export const PAYMENT_METHODS: { value: PaymentMethod; label: string }[] = [
  { value: "cash", label: "Cash" },
  { value: "bank", label: "Bank Transfer" },
  { value: "card", label: "Debit/Credit Card" },
  { value: "jazzcash", label: "JazzCash" },
  { value: "easypaisa", label: "EasyPaisa" },
  { value: "other", label: "Other" },
];

export interface Party {
  id: string;
  name: string;
  phone: string;
  address?: string;
  notes?: string;
  createdAt: string;
  openingBalance?: number; // positive => customer owed this from before (carry-forward)
}

export interface Transaction {
  id: string;
  partyId: string;
  type: TransactionType;
  // sale          => customer owes us (+amount)
  // payment       => customer paid us (-amount)
  // sale_return   => customer returned goods (-amount, stock goes back up)
  // opening       => opening balance carried forward (+amount)
  amount: number;
  description: string;
  date: string;
  receiptNo: string;
  paymentMethod?: PaymentMethod; // only for type === "payment"
  // Optional lace sale details (only for type === "sale")
  laceName?: string;
  stitch?: number;
  rate?: number;
  gazz?: number;
  unitPrice?: number;
  lineTotal?: number;
  // For sale_return, link to original sale (optional)
  linkedSaleId?: string;
}

export interface LaceStockItem {
  id: string;
  name: string;
  color?: string;
  stitch: number;
  rate: number; // sale rate per 1000 stitch
  costPerGaz?: number; // purchase cost per gaz (for P&L)
  quantityGaz: number;
  reorderLevel?: number;
  barcode?: string;
  createdAt: string;
}

export type StockAdjustmentType = "add" | "reduce" | "set";

export interface StockAdjustment {
  id: string;
  stockId: string;
  type: StockAdjustmentType;
  quantity: number;
  reason: string;
  date: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address?: string;
  notes?: string;
  createdAt: string;
  openingBalance?: number; // positive => we owe supplier from before
}

export interface Purchase {
  id: string;
  supplierId: string;
  stockId?: string; // optional - which stock item was purchased
  laceName: string;
  stitch: number;
  rate: number; // purchase rate per 1000 stitch
  gazz: number;
  totalAmount: number;
  amountPaid: number;
  date: string;
  purchaseNo: string;
  description?: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
}

export interface CashClosing {
  id: string;
  date: string; // the day being closed (ISO date at midnight)
  openingCash: number;
  salesCash: number;
  paymentsCash: number;
  expensesCash: number;
  purchasesCash: number;
  expectedCash: number;
  countedCash: number;
  difference: number;
  note?: string;
  closedAt: string;
  closedBy?: string;
}

export type StaffRole = "admin" | "staff";

export interface StaffUser {
  id: string;
  name: string;
  username: string;
  pin: string; // 4-6 digit PIN
  role: StaffRole;
  active: boolean;
  createdAt: string;
}

export interface AppSettings {
  shopName: string;
  shopPhone: string;
  shopAddress: string;
  currency: string;
  // Permission flags for staff role
  staffCanSeeReports: boolean;
  staffCanSeeBackup: boolean;
  staffCanManageStock: boolean;
  staffCanManageParties: boolean;
}

export interface AppData {
  version: number;
  settings: AppSettings;
  parties: Party[];
  transactions: Transaction[];
  stock: LaceStockItem[];
  stockAdjustments: StockAdjustment[];
  suppliers: Supplier[];
  purchases: Purchase[];
  expenses: Expense[];
  cashClosings: CashClosing[];
  staff: StaffUser[];
  receiptCounter: number;
  purchaseCounter: number;
}

export const DEFAULT_DATA: AppData = {
  version: 2,
  settings: {
    shopName: "OMITEK Embroidery",
    shopPhone: "",
    shopAddress: "",
    currency: "Rs.",
    staffCanSeeReports: false,
    staffCanSeeBackup: false,
    staffCanManageStock: false,
    staffCanManageParties: true,
  },
  parties: [],
  transactions: [],
  stock: [],
  stockAdjustments: [],
  suppliers: [],
  purchases: [],
  expenses: [],
  cashClosings: [],
  staff: [],
  receiptCounter: 1,
  purchaseCounter: 1,
};

// Formatting helpers for currency, dates and receipt numbers.

export function formatCurrency(amount: number, currency = "Rs."): string {
  const safe = Number.isFinite(amount) ? amount : 0;
  const formatted = safe.toLocaleString("en-PK", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
  return `${currency} ${formatted}`;
}

export function formatDate(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}

export function formatTime(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}

export function todayISO(): string {
  return new Date().toISOString();
}

export function isSameDay(a: string, b: string): boolean {
  const da = new Date(a);
  const db = new Date(b);
  return (
    da.getFullYear() === db.getFullYear() &&
    da.getMonth() === db.getMonth() &&
    da.getDate() === db.getDate()
  );
}

export function isSameMonth(a: string, b: string): boolean {
  const da = new Date(a);
  const db = new Date(b);
  return (
    da.getFullYear() === db.getFullYear() && da.getMonth() === db.getMonth()
  );
}

// Lace pricing formula:
//   One Gaz price = (Stitch * Rate) / 1000
//   Total (one piece) = One Gaz price * 22
export function calcOneGazPrice(stitch: number, rate: number): number {
  const s = Number(stitch) || 0;
  const r = Number(rate) || 0;
  return (s * r) / 1000;
}

export function calcPiecePrice(stitch: number, rate: number): number {
  return calcOneGazPrice(stitch, rate) * 22;
}

export function calcLineTotal(
  stitch: number,
  rate: number,
  gazz: number,
): number {
  const oneGaz = calcOneGazPrice(stitch, rate);
  return oneGaz * (Number(gazz) || 0);
}

export function startOfDayISO(iso: string): string {
  const d = new Date(iso);
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

export function endOfDayISO(iso: string): string {
  const d = new Date(iso);
  d.setHours(23, 59, 59, 999);
  return d.toISOString();
}

export function dayKey(iso: string): string {
  return new Date(iso).toISOString().slice(0, 10);
}

export function normalizePhone(phone: string): string {
  // strip spaces, dashes; convert to international format for WhatsApp
  let p = phone.replace(/[\s\-()]/g, "");
  if (p.startsWith("+")) p = p.slice(1);
  if (p.startsWith("0")) p = "92" + p.slice(1); // Pakistan default
  return p;
}

"use client";

import { useCallback, useState, useSyncExternalStore } from "react";
import {
  AppData, DEFAULT_DATA, Party, Transaction, LaceStockItem, Expense,
  Supplier, Purchase, StockAdjustment, CashClosing, StaffUser,
} from "./types";
import { todayISO } from "./format";

const STORAGE_KEY = "omitek-embroidery-data-v2";

// Migrate old v1 data (if present) to the new v2 structure.
function migrate(parsed: Partial<AppData>): AppData {
  const base = { ...DEFAULT_DATA };
  const merged: AppData = {
    ...base,
    ...parsed,
    settings: {
      ...base.settings,
      ...(parsed.settings || {}),
      // Force shop name to OMITEK Embroidery if user is on old name
      shopName: parsed.settings?.shopName && parsed.settings.shopName !== "My Lace Shop"
        ? parsed.settings.shopName
        : "OMITEK Embroidery",
    },
    stockAdjustments: parsed.stockAdjustments || [],
    suppliers: parsed.suppliers || [],
    purchases: parsed.purchases || [],
    cashClosings: parsed.cashClosings || [],
    staff: parsed.staff || [],
    purchaseCounter: parsed.purchaseCounter || 1,
    version: 2,
  };
  // Migrate parties that lack openingBalance
  merged.parties = (merged.parties || []).map((p) => ({
    ...p,
    openingBalance: p.openingBalance ?? 0,
  }));
  return merged;
}

function loadData(): AppData {
  if (typeof window === "undefined") return { ...DEFAULT_DATA };
  try {
    // Try new key first
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<AppData>;
      return migrate(parsed);
    }
    // Migrate old key
    const oldRaw = window.localStorage.getItem("lace-bms-data-v1");
    if (oldRaw) {
      const parsed = JSON.parse(oldRaw) as Partial<AppData>;
      const migrated = migrate(parsed);
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
      return migrated;
    }
    return { ...DEFAULT_DATA };
  } catch {
    return { ...DEFAULT_DATA };
  }
}

function saveData(data: AppData) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    window.dispatchEvent(new CustomEvent("omitek-change"));
  } catch (e) {
    console.error("Failed to save data", e);
  }
}

let cachedSnapshot: AppData | null = null;
let cacheKey: string | null = null;
const SERVER_SNAPSHOT: AppData = { ...DEFAULT_DATA };

function subscribe(callback: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  window.addEventListener("storage", callback);
  window.addEventListener("omitek-change", callback);
  window.addEventListener("lace-bms-change", callback as EventListener); // for old listeners
  return () => {
    window.removeEventListener("storage", callback);
    window.removeEventListener("omitek-change", callback);
    window.removeEventListener("lace-bms-change", callback as EventListener);
  };
}

function getSnapshot(): AppData {
  if (typeof window === "undefined") return SERVER_SNAPSHOT;
  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (raw === cacheKey && cachedSnapshot) return cachedSnapshot;
  cacheKey = raw;
  cachedSnapshot = loadData();
  return cachedSnapshot;
}

function getServerSnapshot(): AppData {
  return SERVER_SNAPSHOT;
}

export function uid(prefix = ""): string {
  return `${prefix}${Date.now().toString(36)}${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

export function nextReceiptNo(counter: number): string {
  const year = new Date().getFullYear();
  return `R-${year}-${String(counter).padStart(4, "0")}`;
}

export function nextPurchaseNo(counter: number): string {
  const year = new Date().getFullYear();
  return `PO-${year}-${String(counter).padStart(4, "0")}`;
}

// ---- React hook for the global data store ----
export function useStore() {
  const data = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const [, forceTick] = useState(0);

  const update = useCallback((updater: (prev: AppData) => AppData) => {
    const prev = getSnapshot();
    const next = updater(prev);
    saveData(next);
    cachedSnapshot = next;
    cacheKey = JSON.stringify(next);
    forceTick((t) => t + 1);
  }, []);

  // ---- Settings ----
  const updateSettings = useCallback(
    (patch: Partial<AppData["settings"]>) => {
      update((prev) => ({
        ...prev,
        settings: { ...prev.settings, ...patch },
      }));
    },
    [update],
  );

  // ---- Parties ----
  const addParty = useCallback(
    (input: Omit<Party, "id" | "createdAt">): Party => {
      const party: Party = {
        id: uid("p_"),
        createdAt: todayISO(),
        ...input,
      };
      update((prev) => {
        const next: AppData = { ...prev, parties: [party, ...prev.parties] };
        // Auto-create opening balance transaction if provided
        if (party.openingBalance && party.openingBalance > 0) {
          next.transactions = [
            {
              id: uid("t_"),
              partyId: party.id,
              type: "opening",
              amount: party.openingBalance,
              description: "Opening balance (carry forward)",
              date: party.createdAt,
              receiptNo: `OPEN-${party.id.slice(2, 8)}`,
            },
            ...prev.transactions,
          ];
        }
        return next;
      });
      return party;
    },
    [update],
  );

  const updateParty = useCallback(
    (id: string, patch: Partial<Party>) => {
      update((prev) => ({
        ...prev,
        parties: prev.parties.map((p) =>
          p.id === id ? { ...p, ...patch } : p,
        ),
      }));
    },
    [update],
  );

  const deleteParty = useCallback(
    (id: string) => {
      update((prev) => ({
        ...prev,
        parties: prev.parties.filter((p) => p.id !== id),
        transactions: prev.transactions.filter((t) => t.partyId !== id),
      }));
    },
    [update],
  );

  // ---- Transactions ----
  const addTransaction = useCallback(
    (input: Omit<Transaction, "id" | "date" | "receiptNo"> & { date?: string }) => {
      let created!: Transaction;
      update((prev) => {
        const receiptNo = nextReceiptNo(prev.receiptCounter);
        created = {
          id: uid("t_"),
          date: input.date || todayISO(),
          receiptNo,
          ...input,
        };
        const next: AppData = {
          ...prev,
          transactions: [created, ...prev.transactions],
          receiptCounter: prev.receiptCounter + 1,
        };
        // For sale_return linked to a stock item, restore stock
        if (created.type === "sale_return" && created.gazz && created.laceName) {
          next.stock = prev.stock.map((s) =>
            s.name === created.laceName
              ? { ...s, quantityGaz: s.quantityGaz + (created.gazz || 0) }
              : s,
          );
        }
        return next;
      });
      return created;
    },
    [update],
  );

  const deleteTransaction = useCallback(
    (id: string) => {
      update((prev) => ({
        ...prev,
        transactions: prev.transactions.filter((t) => t.id !== id),
      }));
    },
    [update],
  );

  // ---- Stock ----
  const addStock = useCallback(
    (input: Omit<LaceStockItem, "id" | "createdAt">): LaceStockItem => {
      const item: LaceStockItem = {
        id: uid("s_"),
        createdAt: todayISO(),
        ...input,
      };
      update((prev) => ({ ...prev, stock: [item, ...prev.stock] }));
      return item;
    },
    [update],
  );

  const updateStock = useCallback(
    (id: string, patch: Partial<LaceStockItem>) => {
      update((prev) => ({
        ...prev,
        stock: prev.stock.map((s) => (s.id === id ? { ...s, ...patch } : s)),
      }));
    },
    [update],
  );

  const deleteStock = useCallback(
    (id: string) => {
      update((prev) => ({
        ...prev,
        stock: prev.stock.filter((s) => s.id !== id),
      }));
    },
    [update],
  );

  // ---- Stock Adjustments ----
  const addStockAdjustment = useCallback(
    (input: Omit<StockAdjustment, "id">): StockAdjustment => {
      const adj: StockAdjustment = { id: uid("a_"), ...input };
      update((prev) => {
        const next: AppData = {
          ...prev,
          stockAdjustments: [adj, ...prev.stockAdjustments],
        };
        next.stock = prev.stock.map((s) => {
          if (s.id !== adj.stockId) return s;
          let newQty = s.quantityGaz;
          if (adj.type === "add") newQty += adj.quantity;
          else if (adj.type === "reduce") newQty = Math.max(0, newQty - adj.quantity);
          else if (adj.type === "set") newQty = adj.quantity;
          return { ...s, quantityGaz: newQty };
        });
        return next;
      });
      return adj;
    },
    [update],
  );

  // ---- Suppliers ----
  const addSupplier = useCallback(
    (input: Omit<Supplier, "id" | "createdAt">): Supplier => {
      const supplier: Supplier = {
        id: uid("sup_"),
        createdAt: todayISO(),
        ...input,
      };
      update((prev) => ({ ...prev, suppliers: [supplier, ...prev.suppliers] }));
      return supplier;
    },
    [update],
  );

  const updateSupplier = useCallback(
    (id: string, patch: Partial<Supplier>) => {
      update((prev) => ({
        ...prev,
        suppliers: prev.suppliers.map((s) =>
          s.id === id ? { ...s, ...patch } : s,
        ),
      }));
    },
    [update],
  );

  const deleteSupplier = useCallback(
    (id: string) => {
      update((prev) => ({
        ...prev,
        suppliers: prev.suppliers.filter((s) => s.id !== id),
        purchases: prev.purchases.filter((p) => p.supplierId !== id),
      }));
    },
    [update],
  );

  // ---- Purchases ----
  const addPurchase = useCallback(
    (input: Omit<Purchase, "id" | "date" | "purchaseNo"> & { date?: string }): Purchase => {
      let created!: Purchase;
      update((prev) => {
        const purchaseNo = nextPurchaseNo(prev.purchaseCounter);
        created = {
          id: uid("po_"),
          date: input.date || todayISO(),
          purchaseNo,
          ...input,
        };
        const next: AppData = {
          ...prev,
          purchases: [created, ...prev.purchases],
          purchaseCounter: prev.purchaseCounter + 1,
        };
        // If linked to a stock item, increase its quantity and update cost
        if (created.stockId) {
          next.stock = prev.stock.map((s) => {
            if (s.id !== created.stockId) return s;
            const newQty = s.quantityGaz + created.gazz;
            const newCost = created.gazz > 0 ? (created.rate * created.stitch) / 1000 : s.costPerGaz;
            return {
              ...s,
              quantityGaz: newQty,
              costPerGaz: newCost || s.costPerGaz,
              stitch: created.stitch || s.stitch,
              rate: created.rate || s.rate,
            };
          });
        } else if (created.laceName) {
          // Auto-create stock item if it doesn't exist
          const exists = prev.stock.some((s) => s.name === created.laceName);
          if (!exists) {
            next.stock = [
              {
                id: uid("s_"),
                name: created.laceName,
                stitch: created.stitch,
                rate: created.rate,
                costPerGaz: (created.rate * created.stitch) / 1000,
                quantityGaz: created.gazz,
                createdAt: todayISO(),
              },
              ...prev.stock,
            ];
          }
        }
        return next;
      });
      return created;
    },
    [update],
  );

  const deletePurchase = useCallback(
    (id: string) => {
      update((prev) => ({
        ...prev,
        purchases: prev.purchases.filter((p) => p.id !== id),
      }));
    },
    [update],
  );

  const updatePurchase = useCallback(
    (id: string, patch: Partial<Purchase>) => {
      update((prev) => ({
        ...prev,
        purchases: prev.purchases.map((p) => (p.id === id ? { ...p, ...patch } : p)),
      }));
    },
    [update],
  );

  // ---- Expenses ----
  const addExpense = useCallback(
    (input: Omit<Expense, "id">): Expense => {
      const exp: Expense = { id: uid("e_"), ...input };
      update((prev) => ({ ...prev, expenses: [exp, ...prev.expenses] }));
      return exp;
    },
    [update],
  );

  const deleteExpense = useCallback(
    (id: string) => {
      update((prev) => ({
        ...prev,
        expenses: prev.expenses.filter((e) => e.id !== id),
      }));
    },
    [update],
  );

  // ---- Cash Closing ----
  const saveCashClosing = useCallback(
    (input: Omit<CashClosing, "id" | "closedAt">): CashClosing => {
      const closing: CashClosing = {
        id: uid("c_"),
        closedAt: todayISO(),
        ...input,
      };
      update((prev) => ({
        ...prev,
        // Replace existing closing for same day
        cashClosings: [
          closing,
          ...prev.cashClosings.filter(
            (c) => new Date(c.date).toDateString() !== new Date(closing.date).toDateString(),
          ),
        ],
      }));
      return closing;
    },
    [update],
  );

  // ---- Staff ----
  const addStaff = useCallback(
    (input: Omit<StaffUser, "id" | "createdAt">): StaffUser => {
      const user: StaffUser = {
        id: uid("u_"),
        createdAt: todayISO(),
        ...input,
      };
      update((prev) => ({ ...prev, staff: [...prev.staff, user] }));
      return user;
    },
    [update],
  );

  const updateStaff = useCallback(
    (id: string, patch: Partial<StaffUser>) => {
      update((prev) => ({
        ...prev,
        staff: prev.staff.map((s) => (s.id === id ? { ...s, ...patch } : s)),
      }));
    },
    [update],
  );

  const deleteStaff = useCallback(
    (id: string) => {
      update((prev) => ({
        ...prev,
        staff: prev.staff.filter((s) => s.id !== id),
      }));
    },
    [update],
  );

  // ---- Backup / Restore ----
  const replaceAll = useCallback(
    (next: AppData) => {
      update(() => ({ ...DEFAULT_DATA, ...next }));
    },
    [update],
  );

  const resetAll = useCallback(() => {
    update(() => ({ ...DEFAULT_DATA }));
  }, [update]);

  return {
    data,
    updateSettings,
    addParty,
    updateParty,
    deleteParty,
    addTransaction,
    deleteTransaction,
    addStock,
    updateStock,
    deleteStock,
    addStockAdjustment,
    addSupplier,
    updateSupplier,
    deleteSupplier,
    addPurchase,
    updatePurchase,
    deletePurchase,
    addExpense,
    deleteExpense,
    saveCashClosing,
    addStaff,
    updateStaff,
    deleteStaff,
    replaceAll,
    resetAll,
  };
}

// ---- Pure helpers for computing balances & summaries ----

export function partyBalance(partyId: string, transactions: Transaction[]): number {
  return transactions
    .filter((t) => t.partyId === partyId)
    .reduce((sum, t) => {
      if (t.type === "sale" || t.type === "opening") return sum + t.amount;
      if (t.type === "payment" || t.type === "sale_return") return sum - t.amount;
      return sum;
    }, 0);
}

export function partySalesTotal(partyId: string, transactions: Transaction[]): number {
  return transactions
    .filter((t) => t.partyId === partyId && t.type === "sale")
    .reduce((sum, t) => sum + t.amount, 0);
}

export function partyPaidTotal(partyId: string, transactions: Transaction[]): number {
  return transactions
    .filter((t) => t.partyId === partyId && t.type === "payment")
    .reduce((sum, t) => sum + t.amount, 0);
}

export function partyReturnsTotal(partyId: string, transactions: Transaction[]): number {
  return transactions
    .filter((t) => t.partyId === partyId && t.type === "sale_return")
    .reduce((sum, t) => sum + t.amount, 0);
}

export function supplierBalance(supplierId: string, purchases: Purchase[]): number {
  // positive => we owe supplier money
  return purchases
    .filter((p) => p.supplierId === supplierId)
    .reduce((sum, p) => sum + (p.totalAmount - p.amountPaid), 0);
}

export function supplierPurchaseTotal(supplierId: string, purchases: Purchase[]): number {
  return purchases
    .filter((p) => p.supplierId === supplierId)
    .reduce((sum, p) => sum + p.totalAmount, 0);
}

export function supplierPaidTotal(supplierId: string, purchases: Purchase[]): number {
  return purchases
    .filter((p) => p.supplierId === supplierId)
    .reduce((sum, p) => sum + p.amountPaid, 0);
}

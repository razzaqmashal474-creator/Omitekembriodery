"use client";

import { useState, useEffect, useCallback } from "react";
import { StaffUser } from "./types";

const SESSION_KEY = "omitek-session-user-id";

// Returns the current logged-in staff user id (or null).
export function getSessionUserId(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(SESSION_KEY);
}

export function setSession(userId: string | null) {
  if (typeof window === "undefined") return;
  if (userId) {
    window.localStorage.setItem(SESSION_KEY, userId);
  } else {
    window.localStorage.removeItem(SESSION_KEY);
  }
  window.dispatchEvent(new CustomEvent("omitek-auth-change"));
}

export function useAuth() {
  const [userId, setUserId] = useState<string | null>(() => getSessionUserId());

  useEffect(() => {
    const handler = () => setUserId(getSessionUserId());
    window.addEventListener("omitek-auth-change", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("omitek-auth-change", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);

  const login = useCallback((id: string) => setSession(id), []);
  const logout = useCallback(() => setSession(null), []);

  return { userId, login, logout };
}

// Permission helper: given a user, can they access a feature?
export function canAccess(
  user: StaffUser | null | undefined,
  feature: "reports" | "backup" | "stock" | "parties",
  settings: { staffCanSeeReports: boolean; staffCanSeeBackup: boolean; staffCanManageStock: boolean; staffCanManageParties: boolean },
): boolean {
  if (!user) return false;
  if (user.role === "admin") return true;
  switch (feature) {
    case "reports": return settings.staffCanSeeReports;
    case "backup": return settings.staffCanSeeBackup;
    case "stock": return settings.staffCanManageStock;
    case "parties": return settings.staffCanManageParties;
    default: return false;
  }
}

# OMITEK Embroidery — Deployment Guide

Aapne banwa liya apna lace business app. Ab isay apne domain pe lagane ke 3 tareeqay:

## Option 1 — Vercel (Free, easiest) — Recommended

### Step 1: Project ko download karein
Apne computer pe poora folder zip kar lein (ya GitHub pe push karein).

### Step 2: Vercel pe deploy karein
1. https://vercel.com pe jaayein, free account banayein
2. "Add New Project" click karein
3. Apna GitHub repo connect karein ya folder drag-drop karein
4. Vercel khud detect kar lega Next.js project
5. "Deploy" button dabayein
6. 2 minute mein aapka app live: `https://omitek-embroidery.vercel.app` (jo naam aap choose karein)

### Step 3: Custom domain connect karein (optional)
1. Domain khareedein (Namecheap, GoDaddy, Hostinger — `.com` ~Rs 1800/year, `.pk` ~Rs 3000/year)
2. Vercel dashboard → Project → Settings → Domains → "Add Domain"
3. Apna domain enter karein (e.g. `omitek-embroidery.com`)
4. Vercel aapko DNS records dega — apne domain provider ke DNS settings mein yeh add karein:
   - `A record` ya `CNAME record` (Vercel batayega exact value)
5. 5-10 minute mein domain live ho jaayega, free SSL certificate automatic

## Option 2 — Netlify (similar to Vercel)
1. https://netlify.com pe account banayein
2. Folder ko drag-drop karein "Site deploy" area pe
3. Build command: `bun run build` (ya `npm run build`)
4. Output directory: `.next` (Netlify Next.js plugin khud handle karta hai)
5. Live: `https://omitek.netlify.app`

## Option 3 — Apne VPS / hosting pe
1. Server pe Node.js 20+ install karein
2. `bun install` aur `bun run build` chalayein
3. `bun run start` se production server chalega port 3000 pe
4. Nginx/Caddy se reverse proxy set karein
5. SSL Certbot se free certificate lagayein

---

## Local development (testing ke liye)

```bash
bun install
bun run dev      # dev server
bun run build    # production build
bun run start    # production server
bun run lint     # code quality check
```

---

## Data storage note

App **localStorage** use karta hai (browser-based, sirf usi device pe data rehta hai).
Agar cloud sync chahiye (multi-device, auto-backup) to Supabase free tier integrate karna padega — woh alag feature hai.

**Backup**: Backup & Settings tab se regularly JSON file download karein.

---

## PWA features (jo add kiye gaye)

- ✅ Installable app (phone pe home screen icon)
- ✅ Offline support (service worker caching)
- ✅ App icon (OMITEK branded, scissors + emerald)
- ✅ Splash screen
- ✅ Standalone mode (no browser chrome)
- ✅ Theme color (emerald #10b981)
- ✅ Apple touch icon (iOS home screen)

---

## Branded files

- `/public/icon.svg` — vector logo (kisi bhi size ke liye)
- `/public/icon-192.png` — Android icon (192×192)
- `/public/icon-512.png` — Android icon (512×512)
- `/public/apple-touch-icon.png` — iOS home screen icon (180×180)
- `/public/manifest.webmanifest` — PWA manifest
- `/public/sw.js` — service worker

Agar logo change karna ho to `/scripts/generate_icons.py` edit kar ke sab icons regenerate kar sakte hain:
```bash
python3 scripts/generate_icons.py
```

---

## Production checklist (deploy se pehle)

- [ ] `src/lib/types.ts` mein `DEFAULT_DATA.settings.shopName` set karein apne shop ka naam
- [ ] Shop phone + address (app ke andar Settings tab se)
- [ ] Currency symbol (default "Rs.")
- [ ] Admin account (pehli baar app khulne pe ban jaata hai)
- [ ] Backup JSON file download karein
- [ ] Domain + SSL set karein
- [ ] Vercel/Netlify pe deploy

---

Mazaa! 🎉 Aapka OMITEK Embroidery app apne domain pe live ho jaayega.

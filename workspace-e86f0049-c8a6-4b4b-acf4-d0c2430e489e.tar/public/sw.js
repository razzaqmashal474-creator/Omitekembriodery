// OMITEK Embroidery Service Worker — offline-first caching.
// Strategy:
//   - App shell (HTML navigations): network-first, fallback to cached
//   - Static assets (_next/static, images, fonts): cache-first
//   - API calls: passthrough (no caching, localStorage handles data)

const CACHE_VERSION = "omitek-embroidery-v1";
const OFFLINE_URL = "/";

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) =>
      cache.addAll([
        "/",
        "/manifest.webmanifest",
        "/icon.svg",
        "/icon-192.png",
        "/icon-512.png",
        "/apple-touch-icon.png",
      ]).catch(() => undefined)
    )
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_VERSION)
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Skip Next.js dev HMR / RSC requests
  if (url.pathname.startsWith("/_next/webpack-hmr")) return;
  if (req.headers.get("accept")?.includes("text/x-nextjs-ssg-fetch")) return;

  // Navigations (HTML pages) — network first, fall back to cache, then to root
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(OFFLINE_URL, copy)).catch(() => undefined);
          return res;
        })
        .catch(() =>
          caches.match(req).then((r) => r || caches.match(OFFLINE_URL))
        )
    );
    return;
  }

  // Static assets — cache first, then network (and cache the response)
  if (
    url.pathname.startsWith("/_next/static") ||
    url.pathname.match(/\.(?:js|css|woff2?|ttf|png|jpg|jpeg|svg|gif|webp|ico)$/)
  ) {
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req).then((res) => {
          if (res && res.status === 200) {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then((cache) => cache.put(req, copy)).catch(() => undefined);
          }
          return res;
        }).catch(() => cached);
      })
    );
    return;
  }

  // Everything else — try network, fall back to cache
  event.respondWith(
    fetch(req).catch(() => caches.match(req))
  );
});

// Allow page to trigger skipWaiting on update
self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});
